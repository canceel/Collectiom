/**
 * Created by Administrator on 2014/12/22.
 */
define(['angular', 'js/services'], function(angular) {
    'use strict';
    
    angular.module('cApp.directives', ['cApp.services']);
});
