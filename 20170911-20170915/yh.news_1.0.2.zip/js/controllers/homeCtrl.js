/**
 * Created  by Administrator on 14-12-29.
 */
/*global CONFIGURATION*/
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$state',
        '$timeout',
        '$rootScope',
        'baseService',
        function($scope, cService, log, $state, $timeout, $rootScope, baseService, $ionicTabsDelegate) {
            $scope.index = 1;
            //永辉新闻
            $rootScope.docinfo = {
                type: 1,
                fileList: [],
                pageNo: 1,
                pageSize: 10,
                hasMore: false
            };
            // 业界新闻
            $rootScope.industryinfo = {
                industryList: [],
                newstype: 2,
                pageNo: 1,
                pageSize: 10,
                hasMore: false
            };
            // 招标公告
         /*   $rootScope.tender = {
                tenderList: [],
                pageNo: 1,
                hasMore: false
            };*/
            /**
             * 根据时间进行分别存储为完成任务
             */
            // tab切换
            $scope.selectTabWithIndex = function(index) {
                $ionicTabsDelegate.select(index);
            };
            $scope.getDocDetail = function(newsId) {
                $state.go('detail', {
                    newsId: newsId
                });
            };
            //招标公告
            // $scope.getTenderDetail = function(obj) {
            //     // 招标直接展示pdf
            //     cService.showPdf([{
            //         title: obj.title,
            //         url: obj.url
            //     }]).then(function() {

            //     });
            //     // cService.getTenderFile(url);
            // };
            //永辉新闻
            $scope.isListShow = false;
            $scope.getList = function(isRefresh) {
                $scope.index = 1;
                var params = {
                    type: $rootScope.docinfo.type,
                    pageNo: $rootScope.docinfo.pageNo,
                    pageSize: $rootScope.docinfo.pageSize,
                };
                cService.getDocList(params).then(function(data) {
                    if (data.data == '') {
                        $scope.isListShow = true;
                        $scope.bgColor = {
                            "background-color": "#f4f4f4"
                        }
                    }
                    if (data && data.data && data.data.length === 10) {
                        $scope.docinfo.hasMore = true;
                    } else {
                        $scope.docinfo.hasMore = false;
                    }
                    if (isRefresh) {
                        $rootScope.docinfo.fileList = [];
                    }
                    $rootScope.docinfo.pageNo = $scope.docinfo.pageNo + 1;
                    $rootScope.docinfo.fileList = $scope.docinfo.fileList.concat(data.data);
                    $scope.$broadcast('scroll.refreshComplete');
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });
            };
            // 业界新闻
            $scope.isIndustryShow = false;
            $scope.getIndustryData = function(isRefresh) {
                $scope.index = 2;
                var params = {
                    type: $rootScope.industryinfo.newstype,
                    pageNo: $rootScope.industryinfo.pageNo,
                    pageSize: $rootScope.industryinfo.pageSize,
                };
                cService.getIndustryList(params).then(function(data) {
                    if (data.data == '') {
                        $scope.isIndustryShow = true;
                        $scope.bgColor = {
                            "background-color": "#f4f4f4"
                        }
                    }
                    if (data && data.data && data.data.length === 10) {
                        $scope.industryinfo.hasMore = true;
                    } else {
                        $scope.industryinfo.hasMore = false;
                    }
                    if (isRefresh) {
                        $rootScope.industryinfo.industryList = [];
                    }
                    $rootScope.industryinfo.pageNo = $scope.industryinfo.pageNo + 1;
                    $rootScope.industryinfo.industryList = $scope.industryinfo.industryList.concat(data.data);
                    $scope.$broadcast('scroll.refreshComplete');
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });

            };
            // 业界新闻
            // $scope.isTenderShow = false;
            // $scope.getTenderData = function(isRefresh) {
            //     $scope.index = 3;
            //     var params = {
            //         pageindex: $rootScope.tender.pageNo
            //     };
            //     cService.getTenderList(params).then(function(data) {
            //         if (data.data == '') {
            //             $scope.isTenderShow = true;
            //             $scope.bgColor = {
            //                 "background-color": "#f4f4f4"
            //             }
            //         }
            //         if (data && data.data && data.data.length === 10) {
            //             $scope.tender.hasMore = true;
            //         } else {
            //             $scope.tender.hasMore = false;
            //         }
            //         if (isRefresh) {
            //             $rootScope.tender.tenderList = [];
            //         }
            //         $rootScope.tender.pageNo = $scope.industryinfo.pageNo + 1;
            //         $rootScope.tender.tenderList = $scope.tender.tenderList.concat(data.data);
            //         $scope.$broadcast('scroll.refreshComplete');
            //         $scope.$broadcast('scroll.infiniteScrollComplete');
            //     });

            // };
            // 下拉刷新
            $scope.refreshDetailAll = function(tag) {;
                $scope.industryinfo.pageNo = 1;

                switch (tag) {
                    case 1:
                        $scope.docinfo.pageNo = 1;
                        $scope.docinfo.hasMore = true;
                        $scope.getList(true);
                        break;
                    case 2:
                        $scope.industryinfo.pageNo = 1;
                        $scope.industryinfo.hasMore = true;
                        $scope.getIndustryData(true);
                        break;
                    // case 3:
                    //     $scope.tender.pageNo = 1;
                    //     $scope.tender.hasMore = true;
                    //     $scope.getTenderData(true);
                    //     break;
                }
            };
            // 上拉加载更多
            $scope.loadMoreContent = function(tag) {
                switch (tag) {
                    case 1:
                        $scope.getList(false);
                        break;
                    case 2:
                        $scope.getIndustryData(false);
                    // case 3:
                    //     $scope.getTenderData(false);
                    //     break;
                }


            };
            /*     $scope.getList(false);
            $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                $scope.getList(false);
            });
*/

            $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                if (fromState.name === 'detail' && fromParams.fdId === '-1') {
                    /*$timeout(function() {
                        $scope.getList(false);
                    }, 100);*/
                }
            });


            $scope.getList(true);
            $scope.$apply();
        }
    ];
});