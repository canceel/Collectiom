define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        '$timeout',
        '$state',
        'baseService',
        '$ionicLoading',
        function($scope, cService, log, $rootScope, $stateParams, $timeout, $state, baseService,$ionicLoading) {
            $scope.news = {
                title: '',
                time: '',
                creator: '',
                content: ''
            };

            $scope.getDocDetail = function() {
                cService.getDocDetail($stateParams.newsId).then(function(data) {
                  console.log($scope.content);
                    // $scope.detail = data.list;
                    var json = JSON.parse(data);
                    $scope.news = json;
                    $scope.news.text = json.text.replace(/&lt;/g, '<').replace(/&amp;/g, '&').replace(/&gt;/g, '>');
                });
            };

            $timeout(function() {
                $scope.getDocDetail();
            }, 10);

            $scope.$apply();
        }
    ];
});
