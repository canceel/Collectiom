define(['ionic'], function() {
            'use strict';
            return [
                '$scope',
                'cService',
                'log',
                '$rootScope',
                '$state',
                '$timeout',
                '$daggerToast',
                function($scope, cService, log, $rootScope, $state, $timeout, $daggerToast) {
                    $scope.data=['永辉生活','永辉全球购','咏悦汇','123','456','789','134','222'];

                }
                ];

            });