/**
 * Created by LUOYAN7 on 2015-11-17.
 */
/**
 * Created  by Administrator on 14-12-29.
 */
/* global window*/
/* global define*/
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        '$state',
        '$timeout',
        '$ionicLoading',
        '$rootScope',
        '$stateParams',
        'widgetFactory',
        function($scope, cService, $state, $timeout, $ionicLoading, $rootScope, $stateParams,widgetFactory) {

        $scope.scrollHeight = (window.screen.height - 44) *  window.devicePixelRatio;
        if(CONFIGURATION.com.midea.isPcTest){
            var txtUrl = CONFIGURATION.com.midea.methods.baseUrl + '?alias=mas.x2pr.original&';
            txtUrl += 'docType=' + $stateParams.fileType + '&';
            txtUrl += 'exParam=' + $stateParams.fdId + '&';
            txtUrl += 'fdType=OA&';
            txtUrl += 'quality=' + $stateParams.fileType + '&';
            txtUrl += 'attachment_stamp=&';
            txtUrl += 'token=' + CONFIGURATION.com.midea.userTest.ssoToken;
            $scope.imgSrc = txtUrl ;
        } else{
            widgetFactory.getUser().then(function (user) {
                var txtUrl = CONFIGURATION.com.midea.methods.baseUrl + '?alias=mas.x2pr.original&';
                txtUrl += 'docType=' + $stateParams.fileType + '&';
                txtUrl += 'exParam=' + $stateParams.fdId + '&';
                txtUrl += 'fdType=OA&';
                txtUrl += 'quality=' + $stateParams.fileType + '&';
                txtUrl += 'attachment_stamp=&';
                txtUrl += 'token=' + user.ssoToken;
                $scope.imgSrc = txtUrl ;

                console.log($scope.imgSrc);
            });

        }

            $scope.$apply();
        }
    ];
});
