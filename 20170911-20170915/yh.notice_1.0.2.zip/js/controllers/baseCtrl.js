/**
 * Created by Administrator on 14-12-29.
 */
define([], function() {
    'use strict';

    return [
        'widgetFactory',
        '$ionicPlatform',
        '$ionicHistory',
        '$rootScope',
        function(widgetFactory, $ionicPlatform, $ionicHistory, $rootScope) {
            // 隐藏浮动按钮
            widgetFactory.hideFloat();
            // 隐藏导航控件
            widgetFactory.hideNav();
            // 苹果状态栏变色
            widgetFactory.changeColor([
                253,
                253,
                253,
                1
            ]);

            $rootScope.isHome = false;


            $ionicPlatform.registerBackButtonAction(function() {
                if ($ionicHistory.backView()) {
                    $ionicHistory.goBack();
                } else {
                    $rootScope.exitBack();
                }
            }, 100, 'normalBack');
        }
    ];
});
