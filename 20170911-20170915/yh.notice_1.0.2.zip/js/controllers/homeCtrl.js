/**
 * Created  by Administrator on 14-12-29.
 */
/*global CONFIGURATION*/
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$state',
        '$timeout',
        '$rootScope',
        'baseService',
        function($scope, cService, log, $state, $timeout, $rootScope, baseService) {
            $rootScope.docinfo = {
                fileList: [],
                pageNo: 1,
                pageSize: 10
            };
            $scope.hasMoreContent = true;
            $scope.isShow = false;
            /**
             * 根据时间进行分别存储为完成任务
             */
            $scope.getDocDetail = function(item) {
                $state.go('detail', {
                    fd_id: item.fd_id,
                    fd_name: item.fd_name,
                    doc_subject: item.doc_subject,
                    doc_create_time: item.doc_create_time,
                });

            };
            $scope.getList = function(isRefresh) {
                var params = {
                    pageNo: $rootScope.docinfo.pageNo,
                    pageSize: $rootScope.docinfo.pageSize,
                };

                cService.getDocList(params).then(function(data) {
                    if (data.list == "") {
                        $scope.isShow = true;
                        $scope.bgColor = {
                            "background-color": "#f4f4f4"
                        }
                    }
                    if (data.list.length !== 10) {
                        $scope.hasMoreContent = false;
                    }
                    if (isRefresh) {
                        $rootScope.docinfo.fileList = [];
                    }
                    $rootScope.docinfo.pageNo = $scope.docinfo.pageNo + 1;
                    $rootScope.docinfo.fileList = $scope.docinfo.fileList.concat(data.list);
                    $scope.$broadcast('scroll.refreshComplete');
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                });
            };
            // 下拉刷新
            $scope.refreshDetailAll = function() {
                if ($rootScope.docinfo.fileList != '') {
                    $scope.docinfo.pageNo = 1;
                    $scope.hasMoreContent = true;
                    $scope.getList(true);
                }

            };
            // 上拉加载更多
            $scope.loadMoreContent = function() {
                $scope.getList(false);
            };
            /*     $scope.getList(false);
            $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                $scope.getList(false);
            });
*/

            $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
                if (fromState.name === 'detail' && fromParams.fdId === '-1') {
                    $timeout(function() {
                        $scope.getList(false);
                    }, 100);
                }
            });

            $timeout(function() {
                if (window.CONFIGURATION.extra) {
                    $scope.isShow = false;
                    $rootScope.docinfo.fileList = [];
                    $scope.getDocDetail(-1);
                } else {
                    $scope.getList(false);
                }
            }, 100);
            $scope.$apply();
        }
    ];
});