define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        '$timeout',
        '$state',
        'baseService',
        '$ionicLoading',
        '$daggerToast',
        'widgetFactory',
        function($scope, cService, log, $rootScope, $stateParams, $timeout, $state, baseService,$ionicLoading, $daggerToast, widgetFactory) {
            var baseUrl = CONFIGURATION.com.midea.methods.baseUrl;

            $scope.detailinfo = {
                fdId: $stateParams.fd_id,
                creator: $stateParams.fd_name,
                subject: $stateParams.doc_subject,
                createTime: $stateParams.doc_create_time,
            };

            function strToDate(str) {
                var tempStrs = str.split(' ');
                var dateStrs = tempStrs[0].split('-');
                var year = parseInt(dateStrs[0], 10);
                var month = parseInt(dateStrs[1], 10) - 1;
                var day = parseInt(dateStrs[2], 10);
                var timeStrs = tempStrs[1].split(':');
                var hour = parseInt(timeStrs[0], 10);
                var minute = parseInt(timeStrs[1], 10) - 1;
                var second = parseInt(timeStrs[2], 10);
                var date = new Date(year, month, day, hour, minute, second);

                return date.getTime();
            }

            // 返回附件展示图标的样式名称
            $scope.getDocType = function(value) {
                var info = value.split('.'),
                    type = info[info.length - 1],
                    extensions = {
                    'detail-word': ['doc', 'docx'],
                    'detail-excel': ['xls', 'xlsx'],
                    'detail-ppt': ['ppt', 'pptx'],
                    'detail-acd': ['ai', 'cdr', 'dwg'],
                    'detail-zip': ['zip', 'rar', '7z', 'cab', 'iso'],
                    'detail-img': ['JPG', 'jpg', 'png', 'PNG', 'jpeg', 'JPEG', 'gif', 'GIF', 'bmp', 'BMP'],
                    'detail-pdf': ['pdf', 'PDF'],
                    'detail-txt': ['txt'],
                };

                for (var extension in extensions) {
                    if (extensions.hasOwnProperty(extension) &&
                        extensions[extension].indexOf(type) !== -1) {
                        return extension;
                    }
                }

                return 'detail-other';
            };
            // 返回附件类型信息
            $scope.getFileType = function(value) {
                var info = value.split('.');

                return info[info.length - 1];
            };
            // 处理附件详情
            $scope.toAttachmentDetail = function (Obj) {
                var id = Obj.fd_id;
                var fileType = $scope.getFileType(Obj.fd_file_name);
                var type = $scope.getDocType(Obj.fd_file_name);

                if (type === 'detail-word' ||
                    type === 'detail-excel' ||
                    type === 'detail-ppt' ||
                    type === 'detail-acd' ||
                    type === 'detail-pdf') {
                    var url = baseUrl + '?alias=' + 'mas.x2pr.file';
                    var param = {
                        docType: fileType,
                        exParam: id,
                        fdType: 'OA',
                        quality: 'pdf',
                        attachment_stamp: '',
                        token:CONFIGURATION.com.midea.ssoTokenPlaceholder
                    };
                    cService.request(url, param, {
                        method: 'get'
                    }).then(function(data) {
                        if ((data.result === '1' || data.result === 1) && parseInt(data.pageCount) >= 1) {
                            $scope.pdfUrlList = data.pages;
                            var isIOS = ionic.Platform.isIOS();
                            cService.showPdf($scope.pdfUrlList).then(function() {

                            });

                        } else if (data.code && data.code === 40002) {
                            $daggerToast.show('获取附件失败，请联系管理员！');
                        } else {
                            $daggerToast.show('获取附件失败，请联系管理员！');
                        }
                    });
                } else if (type === 'detail-img') {
                    $state.go('attachment', {
                        fdId: id,
                        system: 'OA',
                        fileType: fileType
                    }); // 新待办查看方式文本查看
                } else if (type === 'detail-txt') {
                    widgetFactory.getUser().then(function (user) {
                        var txtUrl = baseUrl + '?alias=mas.x2pr.original&';
                        txtUrl += 'docType=' + fileType + '&';
                        txtUrl += 'exParam=' + id + '&';
                        txtUrl += 'fdType=OA';
                        txtUrl += 'quality=' + fileType + '&';
                        txtUrl += 'attachment_stamp=&';
                        txtUrl += 'token=' + user.ssoToken;

                        console.log(txtUrl);
                        var txt = [{
                            "url": txtUrl,
                            "title": Obj.fd_file_name.substr(0, Obj.fd_file_name.length - 4),
                            "identifier": 'txt' + Obj.fd_id
                        }];
                        widgetFactory.showTxt(txt).then(function (data) {
                            console.log(data);
                        });
                    });

                } else {
                    $daggerToast.show('暂不支持移动查看，请PC端查看！');
                }
            };

            $scope.getDocDetail = function() {
                var params = {
                    alias: 'oa.notice.detail',
                    flid: $scope.detailinfo.fdId,
                };
                cService.getDocDetail(params).then(function(data) {
                    $scope.detail = data.list;
                });
            }
            $timeout(function() {
                $scope.getDocDetail();
            }, 100);

            $scope.$apply();
        }
    ];
});
