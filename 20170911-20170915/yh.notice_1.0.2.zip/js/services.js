/**
 * Created by Administrator on 2014/11/21.
 */
/*global DOMParser*/
/*global CONFIGURATION*/
define(['angular', 'lib/js/main/services'], function(angular) {
    'use strict';

    /* Services */
    angular.module('cApp.services', ['mApp.services'],
            function($httpProvider) {
                $httpProvider.defaults.headers = {
                    'Content-Type': 'text/xml;UTF-8,application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest',
                    Accept: 'application/xml'
                };
            })
        .service('cService', [
            'cHttpService',
            'widgetFactory',
            '$ionicPopup',
            '$timeout',
            'baseService',
            '$q',
            '$http',
            function(cHttpService, widgetFactory, $ionicPopup, $timeout, baseService, $q, $http) {
                var baseUrl = CONFIGURATION.com.midea.methods.baseUrl; // 请求url
                var services = {

                    /**
                     * 从底座获取用户信息，获取第一次之后会作缓存
                     * @returns {*} Promise
                     */
                    getUser: cHttpService.getUser,
                    /**
                     * 为参数对象添加token
                     * 具体用法：
                     * 在参数中，使参数值等于CONFIGURATION.com.midea.ssoTokenPlaceholder的值，该方法会自动替换正确的值
                     * @param respond 获取用户的respond
                     * @param params 参数对象
                     * @returns {*} 修改后的params参数对象
                     */
                    setToken: cHttpService.setToken,
                    /**
                     * 为参数对象添加uid
                     * 具体用法：
                     * 在参数中，使参数值等于CONFIGURATION.com.midea.uidPlaceholder，该方法会自动替换正确的值
                     * @param respond 获取用户的respond
                     * @param params 修改后的params参数对象
                     * @returns {*}
                     */
                    setLoginName: cHttpService.setLoginName,
                    /**
                     * 递归object用value的值替换掉所有出现的placeholder的值
                     * @param object 递归对象
                     * @param placeholder 要替换的值
                     * @param value 替换后的值
                     */
                    setHolderValue: cHttpService.setHolderValue,
                    /**
                     * 统一请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为JSONP，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    request: cHttpService.request,
                    /**
                     * post请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为POST_JSON，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    post: cHttpService.post,
                    /**
                     * get请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为get，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    get: cHttpService.get,
                    /**
                     * jsonp请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为JSONP，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    jsonp: cHttpService.jsonp,

                    getDocList: function(params) {
                        // TODO 演示数据获取
                        return services.request(CONFIGURATION.com.midea.methods.baseUrl,{
                                alias: 'oa.notice.list',
                                userId:CONFIGURATION.com.midea.uidPlaceholder,
                                pageNo:params.pageNo,
                                pageSize:params.pageSize
                            },{
                                method: 'get'
                            });
                        // TODO 正常数据获取
                        // return services.get(baseUrl, params);
                    },
                    getDocDetail: function(params) {
                        console.log(params)
                            // TODO 演示数据获取
                        return services.request(baseUrl, {
                            alias: params.alias,
                            fdId: params.flid
                        }, { method: 'get' })
                    },
                    getFileUrlList: function(url, params) {
                        return services.get(url, params);
                    },
                    showPdf: function(dataList) {
                        return widgetFactory.showPdf(dataList);
                    },
                };

                return services;
            }
        ])
        .filter('sortListByTime', [function() {
            return function(str) {
                var createTime = '',
                    createTimeStr = '',
                    days = 0,
                    d = '',
                    t = '';

                if (str !== undefined) {

                    createTimeStr = str.split(' ');
                    d = createTimeStr[0].split('-');
                    t = createTimeStr[1].split(':');
                    createTime = parseInt(new Date(d[0], d[1] - 1, d[2], 0, 0, 0).getTime() / (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24);

                    var today = parseInt(new Date().setDate(new Date().getDate()) / (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24);
                    var oneday = parseInt(new Date().setDate(new Date().getDate() - 1) / (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24);
                    var twoday = parseInt(new Date().setDate(new Date().getDate() - 2) / (1000 * 60 * 60 * 24)) * (1000 * 60 * 60 * 24);
                    if (today === createTime) {
                        return t[0] + ':' + t[1];
                    } else if (oneday === createTime) {
                        return '昨天';
                    } else if (twoday === createTime) {
                        return '前天';
                    } else {
                        return d[0] + '-' + d[1] + '-' + d[2];
                    }
                } else {
                    return '';
                }
            };
        }]);
});
