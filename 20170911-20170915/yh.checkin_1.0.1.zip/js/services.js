/**
 * Created by Administrator on 2014/11/21.
 */
define(['angular', 'lib/js/main/services'], function(angular) {
    'use strict';

    /* Services */
    angular.module('cApp.services', ['mApp.services'],
            function($httpProvider) {
                $httpProvider.defaults.headers = {
                    'Content-Type': 'text/xml;UTF-8,application/x-www-form-urlencoded',
                    'X-Requested-With': 'XMLHttpRequest',
                    Accept: 'application/xml'
                };
            })
        .service('cService', [
            'cHttpService', '$q', 'baseService', '$daggerLoadingBar', '$timeout', '$ionicPopup', '$http',
            function(cHttpService, $q, baseService, $daggerLoadingBar, $timeout, $ionicPopup, $http) {
                var services = {
                    baseUrl: CONFIGURATION.com.midea.methods.baseUrl,
                    /**
                     * 从底座获取用户信息，获取第一次之后会作缓存
                     * @returns {*} Promise
                     */
                    getUser: cHttpService.getUser,
                    /**
                     * 为参数对象添加token
                     * 具体用法：
                     * 在参数中，使参数值等于CONFIGURATION.com.midea.ssoTokenPlaceholder的值，该方法会自动替换正确的值
                     * @param respond 获取用户的respond
                     * @param params 参数对象
                     * @returns {*} 修改后的params参数对象
                     */
                    setToken: cHttpService.setToken,
                    /**
                     * 为参数对象添加uid
                     * 具体用法：
                     * 在参数中，使参数值等于CONFIGURATION.com.midea.uidPlaceholder，该方法会自动替换正确的值
                     * @param respond 获取用户的respond
                     * @param params 修改后的params参数对象
                     * @returns {*}
                     */
                    setLoginName: cHttpService.setLoginName,
                    /**
                     * 递归object用value的值替换掉所有出现的placeholder的值
                     * @param object 递归对象
                     * @param placeholder 要替换的值
                     * @param value 替换后的值
                     */
                    setHolderValue: cHttpService.setHolderValue,
                    /**
                     * 统一请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为JSONP，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    request: cHttpService.request,
                    /**
                     * post请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为POST_JSON，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    post: cHttpService.post,
                    /**
                     * get请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为get，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    get: cHttpService.get,
                    /**
                     * jsonp请求方法， 该方法可按需求修改
                     * @param key 请求地址
                     * @param params 参数
                     * @param option $http配置参数，配置参数的method默认为JSONP，可选值为
                                POST_FORMDATA: form-data表单传输, 'Content-Type'为 'multipart/form-data; charset=UTF-8'
                                POST_PAYLOAD: payload传输url参数, 如a=1&b=2&c=3, 'Content-Type'为 'application/x-www-form-urlencoded; charset=UTF-8'
                                post: 传递json对象, 传输前'Content-Type'为 undefined, 传输后为 'application/json;charset=UTF-8'
                                POST_JSON: 传递json字符串, 'Content-Type'为 'application/json;charset=UTF-8'
                                get: get请求接口
                                JSONP: jsonp请求接口, 如angular_1({"foo": "bar"});
                                其他自定义的值: 直接调用$http进行传输
                     * @returns {*} Promise
                     */
                    jsonp: cHttpService.jsonp,
                    parseXML: function(source) {
                        var o = null;

                        try {
                            var domParser = new DOMParser();

                            o = domParser.parseFromString(source, 'text/xml');

                            return o.documentElement;
                        } catch (e) {
                            try {
                                o = this.getIEXmlAX();
                                o.loadXML(source);

                                return o.documentElement;
                            } catch (e1) {
                                return null;
                            }
                        }
                    },
                    getNodeValue: function(xmlObject, nodeName, index) {
                        var target = '';

                        if (index >= 0) {
                            try {
                                target = xmlObject.getElementsByTagName(nodeName)[index].firstChild.data;
                            } catch (e) {
                                return target;
                            }
                        } else {
                            try {
                                target = xmlObject.getElementsByTagName(nodeName);
                            } catch (e) {
                                return target;
                            }
                        }

                        return target;
                    },
                    xmlToJson: function(xml, tagName) {
                        xml = xml.replace(/&quot;/g, "'");
                        var _obj_xmlDoc = services.parseXML(xml),
                            list = _obj_xmlDoc.getElementsByTagName(tagName),
                            obj = '{',
                            listObj = [];

                        if (!!list && list.length > 0) {
                            for (var i = 0; i < list.length; i += 1) {
                                if (list[i].attributes.length > 0) {
                                    for (var j = 0; j < list[i].attributes.length; j += 1) {
                                        var attribute = list[i].attributes.item(j);

                                        obj += '"' + attribute.nodeName + '":"' + attribute.nodeValue + '",';
                                    }
                                }
                                obj = obj.substring(0, obj.length - 1) + '}';
                                listObj[i] = JSON.parse(services.jsonStrReplace(obj));
                                obj = '{';
                            }
                        }

                        return listObj;
                    },
                    xmlToJson2: function(xml, tagName) {
                        xml = xml.replace(/&quot;/g, "'");
                        var _obj_xmlDoc = services.parseXML(xml),
                            list = _obj_xmlDoc.getElementsByTagName(tagName),
                            listObj = [];

                        if (!!list && list.length > 0) {
                            for (var i = 0; i < list.length; i += 1) {
                                if (list[i].childNodes.length > 0) {
                                    var obj = {};
                                    for (var j = 0; j < list[i].childNodes.length; j += 1) {
                                        obj[list[i].childNodes[j].tagName] = list[i].childNodes[j].textContent.replace(/^\s*((?:[\S\s]*\S)?)\s*$/, '$1')
                                    }
                                    listObj.push(obj);
                                }
                            }
                        }

                        return listObj;
                    },
                    // 月考勤登录  夏谷系统
                    getAttendToken: function() {
                        return services.request(services.baseUrl, {
                            alias: 'sharegoo.attend.login',
                        }, { method: 'get' });
                    },
                    /**
                     * 月考勤日历  个人月考勤 日历数据
                     * @param  {String} beginDate [开始日期]
                     * @param  {String} endDate   [结束日期]
                     * @param  {String} userId    [用户id]
                     * @return {*}                [Promise]
                     */
                    getAttendanceList: function(beginDate, endDate, userId) {
                        var defer = $q.defer();
                        services.getAttendToken().then(function(res) {
                            if (0 == res.result) {
                                services.request(services.baseUrl, {
                                    alias: 'sharegoo.attend.detail',
                                    arg0: res.msg.LoginResult,
                                    arg1: ('<?xml version="1.0" encoding="utf-8" ?><DocumentElement><Table><empid>' +
                                            userId + '</empid><begindate>' + beginDate +
                                            '</begindate><enddate>' + endDate +
                                            '</enddate></Table></DocumentElement>')
                                        .replace(/\</g, '&lt;').replace(/\>/g, '&gt;').replace(/\"/g, '&quot;')
                                }, { method: 'get' }).then(function(result) {
                                    defer.resolve(result);
                                });
                            } else {
                                defer.resolve(-1);
                                //$daggerToast.show('月考勤登录失败');
                            }
                        });

                        return defer.promise;
                    },
                    /**
                     * 从本地data.json文件获取信息
                     * @param  {String} key [关键字]
                     * @param  {Number} index    []
                     * @return {*}                [Promise]
                     */
                    getStaticJson: function(key, index) {
                        var defer = $q.defer();
                        var staticJson = baseService.items.get('todo', 'staticJson');

                        if (staticJson) {
                            if (index || index === 0) {
                                defer.resolve(staticJson[key][index]);
                            } else {
                                defer.resolve(staticJson[key]);
                            }
                        } else {
                            $http.get('static/data.json').then(function(data) {
                                baseService.items.set('todo', 'staticJson', data.data);

                                if (index || index === 0) {
                                    defer.resolve(data.data[key][index]);
                                } else {
                                    defer.resolve(data.data[key]);
                                }
                            });
                        }

                        return defer.promise;
                    },
                    /**
                     * 获取年休假数据
                     * @param  {String} beginDate [开始日期]
                     * @param  {String} userId    [用户id]
                     * @return {*}                [Promise]
                     */
                    getVacationData: function(beginDate, userId) {
                        var defer = $q.defer();
                        services.getAttendToken().then(function(res) {
                            if (0 == res.result) {
                                services.request(services.baseUrl, {
                                    alias: 'sharegoo.attend.checkHours',
                                    arg0: res.msg.LoginResult,
                                    arg1: ('<?xml version="1.0" encoding="utf-8" ?><DocumentElement><Table><empid>' +
                                            userId + '</empid><begindate>' + beginDate +
                                            '</begindate></Table></DocumentElement>')
                                        .replace(/\</g, '&lt;').replace(/\>/g, '&gt;').replace(/\"/g, '&quot;')
                                }, { method: 'get' }).then(function(result) {
                                    defer.resolve(result);
                                });
                            } else {
                                defer.resolve(-1);
                            }
                        });

                        return defer.promise;
                    },
                    /**
                     * 假期申请提交
                     * @param  {[JSON]} param 传参
                     * @return {*} [Promise]
                     */
                    submitVacationApply: function(param) {
                        param.fdApplicantJobNum = window.CONFIGURATION.com.midea.uidPlaceholder;
                        return services.getUser().then(function(res) {
                            param.fdApplicantPhone = res.mobile;
                            param.fdApplicantName = res.cn;
                            param.docSubject = res.cn + '于' + services.dateFormat(new Date(), 'yyyy-MM-dd hh:mm') + '在掌上永辉提交的假期申请表';
                            return services.request(services.baseUrl, {
                                alias: 'oa.checkin.add',
                                templateId: 'H008',
                                fdId: '', // 传空
                                loginName: window.CONFIGURATION.com.midea.uidPlaceholder,
                                data: JSON.stringify(param)
                            }, {
                                method: 'POST_FORMDATA'
                            });
                        });
                    },
                    /**
                     * 销假申请提交
                     * @param  {JSON} params 传参
                     * @return {*}        Promise
                     */
                    submitResumeleave: function(params) {
                        params.fdApplicantJobNum = window.CONFIGURATION.com.midea.uidPlaceholder;
                        return services.getUser().then(function(res) {
                            params.fdApplicantPhone = res.mobile;
                            params.fdApplicantName = res.cn;
                            params.docSubject = res.cn + '于' + services.dateFormat(new Date(), 'yyyy-MM-dd hh:mm') + '在掌上永辉提交的销假申请表';
                            return services.request(services.baseUrl, {
                                alias: 'oa.checkin.add',
                                templateId: 'H010',
                                fdId: '', // 传空
                                loginName: window.CONFIGURATION.com.midea.uidPlaceholder,
                                data: JSON.stringify(params)
                            }, {
                                method: 'POST_FORMDATA'
                            });
                        });
                    },
                    /**
                     * 加班申请提交
                     * @param  {[JSON]} param 传参
                     * @return {*} [Promise]
                     */
                    submitOverworkApply: function(params) {
                        params.fdApplicantJobNum = window.CONFIGURATION.com.midea.uidPlaceholder;
                        return services.getUser().then(function(res) {
                            params.fdApplicantPhone = res.mobile;
                            params.fdApplicantName = res.cn;
                            params.docSubject = res.cn + '于' + services.dateFormat(new Date(), 'yyyy-MM-dd hh:mm') + '在掌上永辉提交的加班申请表';
                            return services.request(services.baseUrl, {
                                alias: 'oa.checkin.add',
                                templateId: 'H011',
                                fdId: '', // 传空
                                loginName: window.CONFIGURATION.com.midea.uidPlaceholder,
                                data: JSON.stringify(params)
                            }, {
                                method: 'POST_FORMDATA'
                            });
                        });
                    },
                    /**
                     * 补卡申请提交
                     * @param  {[JSON]} param 传参
                     * @return {*} [Promise]
                     */
                    submitRetroactiveApply: function(params) {
                        params.fdApplicantJobNum = window.CONFIGURATION.com.midea.uidPlaceholder;
                        return services.getUser().then(function(res) {
                            params.fdApplicantPhone = res.mobile;
                            params.fdApplicantName = res.cn;
                            params.docSubject = res.cn + '于' + services.dateFormat(new Date(), 'yyyy-MM-dd hh:mm') + '在掌上永辉提交的补卡申请表';
                            return services.request(services.baseUrl, {
                                alias: 'oa.checkin.add',
                                templateId: 'H009',
                                fdId: '', // 传空
                                loginName: window.CONFIGURATION.com.midea.uidPlaceholder,
                                data: JSON.stringify(params)
                            }, {
                                method: 'POST_FORMDATA'
                            });
                        });
                    },
                    /**
                     * 调班申请提交
                     * @param  {[type]} params [description]
                     * @return {[type]}        [description]
                     */
                    submitMoveworkApply: function(params) {
                        params.fdApplicantJobNum = window.CONFIGURATION.com.midea.uidPlaceholder;
                        return services.getUser().then(function(res) {
                            params.fdApplicantPhone = res.mobile;
                            params.fdApplicantName = res.cn;
                            params.docSubject = res.cn + '于' + services.dateFormat(new Date(), 'yyyy-MM-dd hh:mm') + '在掌上永辉提交的调班申请表';
                            return services.request(services.baseUrl, {
                                alias: 'oa.checkin.add',
                                templateId: 'H012',
                                fdId: '', // 传空
                                loginName: window.CONFIGURATION.com.midea.uidPlaceholder,
                                data: JSON.stringify(params)
                            }, {
                                method: 'POST_FORMDATA'
                            });
                        });
                    },
                    /**
                     * 请假详情
                     */
                    getVacationDetail: function(modelId) {
                        return services.request(services.baseUrl, {
                            alias: 'oa.todo.getTodoContentInfo',
                            fdId: modelId,
                            templateId: 'com.landray.kmss.yh.hr.model.YhHrLeave',
                            loginName: CONFIGURATION.com.midea.uidPlaceholder,
                            extend: {}
                        }, { method: 'get' });
                    },
                    /**
                     * 请假、销假、补卡、加班申请列表
                     * @param  {[type]} templateId [description]
                     * @param  {[type]} pageNo     [当前页]
                     * @param  {[type]} rowSize    [每页大小]
                     * @param  {[type]} extend     [description]
                     * @return {*}            Promise
                     */
                    findList: function(templateId, pageNo, rowSize, extend) {
                        return services.request(services.baseUrl, {
                            alias: 'oa.todo.findList',
                            templateId: templateId,
                            loginName: CONFIGURATION.com.midea.uidPlaceholder,
                            rowSize: rowSize,
                            pageNo: pageNo,
                            extend: extend
                        }, { method: 'get' });
                    },
                    /**
                     * 请假时长计算
                     * @param  {String} beginDateTime [开始时间]
                     * @param  {String} endDateTime   [结束时间]
                     * @return {*}               Promise
                     */
                    calculateHours: function(beginDateTime, endDateTime) {
                        return services.request(services.baseUrl, {
                            alias: 'oa.vacation.time',
                            access_token: CONFIGURATION.com.midea.ssoTokenPlaceholder,
                            s_bean: 'yhHrAddressTreeData',
                            type: 'calHours',
                            fdJobNo: CONFIGURATION.com.midea.uidPlaceholder,
                            beginDateTime: beginDateTime,
                            endDateTime: endDateTime
                        }, { method: 'get' });
                    },
                    // 获取搜索待选列表
                    commonSearch: function (params) {
                        return services.request(services.baseUrl, params, {
                            method: 'get'
                        });
                    },
                    confirm: function(text) {
                        var pop = $ionicPopup.show({
                            //title: '标题',
                            template: text,
                            buttons: [{ // Array[Object] (optional). Buttons to place in the popup footer.
                                text: '再看看',
                                type: 'button-positive button-clear', //button-default
                                onTap: function(e) {
                                    // e.preventDefault() will stop the popup from closing when tapped.
                                    //e.preventDefault();
                                    return false;
                                    pop.close();
                                }
                            }, {
                                text: '确定',
                                type: 'button-positive button-clear',
                                onTap: function(e) {
                                    // Returning a value will cause the promise to resolve with the given value.
                                    return true;
                                    pop.close();
                                }
                            }]
                        });
                        return pop;
                    },
                    /*/!**
                     * 对日期进行格式化，
                     * @param date 要格式化的日期
                     * @param format 进行格式化的模式字符串
                     *     支持的模式字母有：
                     *     y:年,
                     *     M:年中的月份(1-12),
                     *     d:月份中的天(1-31),
                     *     h:小时(0-23),
                     *     m:分(0-59),
                     *     s:秒(0-59),
                     *     S:毫秒(0-999),
                     *     q:季度(1-4)
                     * @return String
                     */
                    dateFormat: function(date, format) {
                        format = format || 'yyyy-MM-dd';
                        date = date || new Date();
                        var map = {
                            'M': date.getMonth() + 1, //月份
                            'd': date.getDate(), //日
                            'h': date.getHours(), //小时
                            'm': date.getMinutes(), //分
                            's': date.getSeconds(), //秒
                            'q': Math.floor((date.getMonth() + 3) / 3), //季度
                            'S': date.getMilliseconds() //毫秒
                        };
                        format = format.replace(/([yMdhmsqS])+/g, function(all, t) {
                            var v = map[t];
                            if (v !== undefined) {
                                if (all.length > 1) {
                                    v = '0' + v;
                                    v = v.substr(v.length - 2);
                                }
                                return v;
                            } else if (t === 'y') {
                                return (date.getFullYear() + '').substr(4 - all.length);
                            }
                            return all;
                        });
                        return format;
                    }
                };

                return services;
            }
        ])
        .filter('show_time', [function() {
            return function(text) {
                if (text) {
                    var time = text.split(' ')[0].split('-');
                    return time[1] + '-' + time[2];
                } else {
                    return '';
                }
            };
        }]).filter('dateSplit', function() {
            // 数据库返回的null 改成0
            return function(text, param) {
                if (text) {
                    var d = new Date(text);
                    if (param === 'day') {
                        var day = d.getDate();
                        return (day < 10 ? '0' + day : day);
                    } else if (param === 'month') {
                        var months = ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'];
                        return months[d.getMonth()]
                    } else if (param === 'week') {
                        var months = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
                        return months[d.getDay()]
                    }
                } else {
                    return '';
                }
            }
        });
});