/**
 * Created by Administrator on 2014/12/22.
 */
define(['angular', 'js/services'], function(angular) {
    'use strict';

    angular.module('cApp.directives', ['cApp.services'])
        .factory('$mePerpetualCalendar', ['$rootScope', function($rootScope) {
            /*****************************************************************************
             日期资料
             *****************************************************************************/
            var lunarInfo = [0x04bd8,0x04ae0,0x0a570,0x054d5,0x0d260,0x0d950,0x16554,0x056a0,0x09ad0,0x055d2,// 1900-1909
                    0x04ae0,0x0a5b6,0x0a4d0,0x0d250,0x1d255,0x0b540,0x0d6a0,0x0ada2,0x095b0,0x14977,// 1910-1919
                    0x04970,0x0a4b0,0x0b4b5,0x06a50,0x06d40,0x1ab54,0x02b60,0x09570,0x052f2,0x04970,// 1920-1929
                    0x06566,0x0d4a0,0x0ea50,0x06e95,0x05ad0,0x02b60,0x186e3,0x092e0,0x1c8d7,0x0c950,// 1930-1939
                    0x0d4a0,0x1d8a6,0x0b550,0x056a0,0x1a5b4,0x025d0,0x092d0,0x0d2b2,0x0a950,0x0b557,// 1940-1949
                    0x06ca0,0x0b550,0x15355,0x04da0,0x0a5b0,0x14573,0x052b0,0x0a9a8,0x0e950,0x06aa0,// 1950-1959
                    0x0aea6,0x0ab50,0x04b60,0x0aae4,0x0a570,0x05260,0x0f263,0x0d950,0x05b57,0x056a0,// 1960-1969
                    0x096d0,0x04dd5,0x04ad0,0x0a4d0,0x0d4d4,0x0d250,0x0d558,0x0b540,0x0b6a0,0x195a6,// 1970-1979
                    0x095b0,0x049b0,0x0a974,0x0a4b0,0x0b27a,0x06a50,0x06d40,0x0af46,0x0ab60,0x09570,// 1980-1989
                    0x04af5,0x04970,0x064b0,0x074a3,0x0ea50,0x06b58,0x055c0,0x0ab60,0x096d5,0x092e0,// 1990-1999
                    0x0c960,0x0d954,0x0d4a0,0x0da50,0x07552,0x056a0,0x0abb7,0x025d0,0x092d0,0x0cab5,// 2000-2009
                    0x0a950,0x0b4a0,0x0baa4,0x0ad50,0x055d9,0x04ba0,0x0a5b0,0x15176,0x052b0,0x0a930,// 2010-2019
                    0x07954,0x06aa0,0x0ad50,0x05b52,0x04b60,0x0a6e6,0x0a4e0,0x0d260,0x0ea65,0x0d530,// 2020-2029
                    0x05aa0,0x076a3,0x096d0,0x04bd7,0x04ad0,0x0a4d0,0x1d0b6,0x0d250,0x0d520,0x0dd45,// 2030-2039
                    0x0b5a0,0x056d0,0x055b2,0x049b0,0x0a577,0x0a4b0,0x0aa50,0x1b255,0x06d20,0x0ada0,// 2040-2049
                    /**Add By JJonline@JJonline.Cn**/
                    0x14b63,0x09370,0x049f8,0x04970,0x064b0,0x168a6,0x0ea50, 0x06b20,0x1a6c4,0x0aae0,// 2050-2059
                    0x0a2e0,0x0d2e3,0x0c960,0x0d557,0x0d4a0,0x0da50,0x05d55,0x056a0,0x0a6d0,0x055d4,// 2060-2069
                    0x052d0,0x0a9b8,0x0a950,0x0b4a0,0x0b6a6,0x0ad50,0x055a0,0x0aba4,0x0a5b0,0x052b0,// 2070-2079
                    0x0b273,0x06930,0x07337,0x06aa0,0x0ad50,0x14b55,0x04b60,0x0a570,0x054e4,0x0d160,// 2080-2089
                    0x0e968,0x0d520,0x0daa0,0x16aa6,0x056d0,0x04ae0,0x0a9d4,0x0a2d0,0x0d150,0x0f252,// 2090-2099
                    0x0d520],// 2100
                solarMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
                Gan = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸'],
                Zhi = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥'],
                // Animals = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪'],
                solarTerm = ['小寒', '大寒', '立春', '雨水', '惊蛰', '春分', '清明', '谷雨', '立夏', '小满', '芒种', '夏至', '小暑', '大暑', '立秋', '处暑', '白露', '秋分', '寒露', '霜降', '立冬', '小雪', '大雪', '冬至'],
                sTermInfo = [0, 21208, 42467, 63836, 85337, 107014, 128867, 150921, 173149, 195551, 218072, 240693, 263343, 285989, 308563, 331033, 353350, 375494, 397447, 419210, 440795, 462224, 483532, 504758],
                nStr1 = ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十'],
                nStr2 = ['初', '十', '廿', '卅', '　'],
                // monthName = ['1 月', '2 月', '3 月', '4 月', '5 月', '6 月', '7 月', '8 月', '9 月', '10 月', '11 月', '12 月'];

                // 国历节日 *表示放假日
                sFtv = [
                    '0101*元旦',
                    '0214 情人节',
                    '0308 妇女节',
                    '0312 植树节',
                    '0401 愚人节',
                    '0501 劳动节',
                    '0504 青年节',
                    '0601 儿童节',
                    '0701 建党节',
                    '0801 建军节',
                    '0910 教师节',
                    '1001*国庆节',
                    '1006 老人节',
                    '1224 平安夜',
                    '1225 圣诞节'],

                // 农历节日 *表示放假日
                lFtv = [
                    '0101*春节',
                    '0115 元宵节',
                    '0505 端午节',
                    '0707 七夕节',
                    '0815 中秋节',
                    '0909 重阳节',
                    '1208 腊八节',
                    '0100*除夕'],

                // 某月的第几个星期几
                wFtv = ['0520 母亲节', '0630'],

                Today = new Date(),
                tY = Today.getFullYear(),
                tM = Today.getMonth(),
                tD = Today.getDate();

            /*****************************************************************************
             日期计算
             *****************************************************************************/

            /* jshint -W016 */
            // 传回农历 y年的总天数
            function lYearDays(y) {
                var i, sum = 348;

                for (i = 0x8000; i > 0x8; i >>= 1) {
                    sum += (lunarInfo[y - 1900] & i) ? 1 : 0;
                }

                return (sum + leapDays(y));
            }

            // 传回农历 y年闰月的天数
            function leapDays(y) {
                if (leapMonth(y)) {
                    return ((lunarInfo[y - 1900] & 0x10000) ? 30 : 29);
                } else {
                    return (0);
                }
            }

            // 传回农历 y年闰哪个月 1-12 , 没闰传回 0
            function leapMonth(y) {
                return (lunarInfo[y - 1900] & 0xf);
            }

            // 传回农历 y年m月的总天数
            function monthDays(y, m) {
                return ((lunarInfo[y - 1900] & (0x10000 >> m)) ? 30 : 29);
            }

            // 算出农历, 传入日期物件, 传回农历日期物件
            // 该物件属性有 .year .month .day .isLeap .yearCyl .dayCyl .monCyl
            function Lunar(objDate) {
                var i,
                    leap = 0,
                    temp = 0,
                    baseDate = new Date(1900, 0, 31),
                    offset = (objDate - baseDate) / 86400000;

                this.dayCyl = offset + 40;
                this.monCyl = 14;

                for (i = 1900; i < 2050 && offset > 0; i++) {
                    temp = lYearDays(i);
                    offset -= temp;
                    this.monCyl += 12;
                }

                if (offset < 0) {
                    offset += temp;
                    i--;
                    this.monCyl -= 12;
                }

                this.year = i;
                this.yearCyl = i - 1864;

                leap = leapMonth(i); // 闰哪个月
                this.isLeap = false;

                for (i = 1; i < 13 && offset > 0; i++) {
                    // 闰月
                    if (leap > 0 && i === (leap + 1) && !this.isLeap) {
                        --i;
                        this.isLeap = true;
                        temp = leapDays(this.year);
                    } else {
                        temp = monthDays(this.year, i);
                    }

                    // 解除闰月
                    if (this.isLeap && i === (leap + 1)) {
                        this.isLeap = false;
                    }

                    offset -= temp;

                    if (!this.isLeap) {
                        this.monCyl++;
                    }
                }

                if (offset === 0 && leap > 0 && i === leap + 1) {
                    if (this.isLeap) {
                        this.isLeap = false;
                    } else {
                        this.isLeap = true;
                        --i;
                        --this.monCyl;
                    }
                }

                if (offset < 0) {
                    offset += temp;
                    --i;
                    --this.monCyl;
                }

                this.month = i;
                this.day = offset + 1;
            }

            // 传回国历 y年某m+1月的天数
            function solarDays(y, m) {
                if (m === 1) {
                    return (((y % 4 == 0) && (y % 100 != 0) || (y % 400 == 0)) ? 29 : 28);
                } else {
                    return (solarMonth[m]);
                }
            }

            // 传入 offset 传回干支, 0=甲子
            function cyclical(num) {
                return (Gan[num % 10] + Zhi[num % 12]);
            }

            // 某年的第n个节气为几日(从0小寒起算)
            function sTerm(y, n) {
                var offDate = new Date((31556925974.7 * (y - 1900) + sTermInfo[n] * 60000) + Date.UTC(1900, 0, 6, 2, 5));

                return (offDate.getUTCDate());
            }

            // 中文日期
            function lunarDay(d) {
                var s;

                switch (d) {
                    case 10:
                        s = '初十';
                        break;

                    case 20:
                        s = '二十';
                        break;

                    case 30:
                        s = '三十';
                        break;
                    default :
                        s = nStr2[Math.floor(d / 10)];
                        s += nStr1[d % 10];
                }

                return (s);
            }

            // 月历属性
            function CalElement(sYear, sMonth, sDay, week, lYear, lMonth, lDay, isLeap, cYear, cMonth, cDay) {
                var self = this;

                self.isToday = false;
                self.scheduling = false;
                //self.canClick = true;
                // 国历
                self.sYear = sYear;
                self.sMonth = sMonth;
                self.sDay = sDay;
                self.week = week;
                // 农历
                self.lYear = lYear;
                self.lMonth = lMonth;
                self.lDay = lunarDay(lDay);
                self.isLeap = isLeap;
                // 干支
                self.cYear = cYear;
                self.cMonth = cMonth;
                self.cDay = cDay;

                self.color = '';

                self.lunarFestival = ''; // 农历节日
                self.solarFestival = ''; // 国历节日
                self.solarTerms = ''; // 节气
                self.tagBottom = ''; // 每日底部样式
                self.tagTop = ''; // 每日顶部样式
                self.isSelect = false; // 是否选中
                self.isFuture = false; // 是否该日期大于当前日期
            }

            // ============================== 传回月历物件 (y年,m+1月)
            function Calendar(y, m) {
                var sDObj, lDObj, lY, lM, lD = 1,
                    lL, lX = 0,
                    tmp1, tmp2,
                    lDPOS = new Array(3),
                    n = 0,
                    firstLM = 0;

                sDObj = new Date(y, m, 1); // 当月一日日期

                this.length = solarDays(y, m); // 国历当月天数
                this.firstWeek = sDObj.getDay(); // 国历当月1日星期几

                for (var i = 0; i < this.length; i++) {
                    if (lD > lX) {
                        sDObj = new Date(y, m, i + 1); // 当月一日日期
                        lDObj = new Lunar(sDObj); // 农历
                        lY = lDObj.year; // 农历年
                        lM = lDObj.month; // 农历月
                        lD = lDObj.day; // 农历日
                        lL = lDObj.isLeap; // 农历是否闰月
                        lX = lL ? leapDays(lY) : monthDays(lY, lM); // 农历当月最後一天

                        if (n === 0) {
                            firstLM = lM;
                        }
                        lDPOS[n++] = i - lD + 1;
                    }

                    // sYear,sMonth,sDay,week,
                    // lYear,lMonth,lDay,isLeap,
                    // cYear,cMonth,cDay
                    this[i] = new CalElement(y, m + 1, i + 1, (i + this.firstWeek) % 7,
                        lY, lM, lD++, lL,
                        cyclical(lDObj.yearCyl), cyclical(lDObj.monCyl), cyclical(lDObj.dayCyl++));

                    if ((i + this.firstWeek) % 7 === 0) {
                        this[i].color = 'red';
                    } // 周日颜色

                    if ((i + this.firstWeek) % 14 === 13) {
                        this[i].color = 'red';
                    } // 周休二日颜色
                }

                // 节气
                tmp1 = sTerm(y, m * 2) - 1;
                tmp2 = sTerm(y, m * 2 + 1) - 1;
                this[tmp1].solarTerms = solarTerm[m * 2];
                this[tmp2].solarTerms = solarTerm[m * 2 + 1];

                if (m === 3) {
                    this[tmp1].color = 'red';
                } // 清明颜色

                // 国历节日
                for (i in sFtv) {
                    if (sFtv[i].match(/^(\d{2})(\d{2})([\s\*])(.+)$/)) {
                        if (Number(RegExp.$1) == (m + 1)) {
                            this[Number(RegExp.$2) - 1].solarFestival += RegExp.$4 + ' ';

                            if (RegExp.$3 == '*') this[Number(RegExp.$2) - 1].color = 'red';
                        }
                    }
                }

                // 月周节日
                for (i in wFtv) {
                    if (wFtv[i].match(/^(\d{2})(\d)(\d)([\s\*])(.+)$/)) {
                        if (Number(RegExp.$1) == (m + 1)) {
                            tmp1 = Number(RegExp.$2);
                            tmp2 = Number(RegExp.$3);
                            this[((this.firstWeek > tmp2) ? 7 : 0) + 7 * (tmp1 - 1) + tmp2 - this.firstWeek].solarFestival += RegExp.$5 + ' ';
                        }
                    }
                }

                // 农历节日
                for (i in lFtv) {
                    if (lFtv[i].match(/^(\d{2})(.{2})([\s\*])(.+)$/)) {
                        tmp1 = Number(RegExp.$1) - firstLM;

                        if (tmp1 == -11) {
                            tmp1 = 1;
                        }

                        if (tmp1 >= 0 && tmp1 < n) {
                            tmp2 = lDPOS[tmp1] + Number(RegExp.$2) - 1;

                            if (tmp2 >= 0 && tmp2 < this.length) {
                                this[tmp2].lunarFestival += RegExp.$4 + ' ';

                                if (RegExp.$3 == '*') {
                                    this[tmp2].color = 'red';
                                }
                            }
                        }
                    }
                }

                // 黑色星期五
                // if ((this.firstWeek + 12) % 7 == 5) {
                //     this[12].solarFestival += '黑色星期五 ';
                // }

                // 今日
                if (y === tY && m === tM) {
                    this[tD - 1].isToday = true;
                }
                // 有排班信息
                //if (y === tY) {
                //    var b =[1,2,3];
                //    if (b) {
                //        for (var j = 0; j < b.length; j++) {
                //            this[b[j]-1].scheduling = true;
                //        }
                //    }
                //}
            }

            return {
                Calendar: Calendar,
                lunarDate: lunarDay
            };
        }])
        .directive('meCalender2', [function() {
            return {
                restrict: 'E',
                require: ['meCalender'],
                template: '<div class="calendar">' +
                '<div class="calendar-title" ng-if="!hideDay"></div>' +
                '<div class="row calendar-week" ng-if="!hideDay"><div class="col" ng-repeat="w in [0,1,2,3,4,5,6]">{{weekFormat(w)}}</div></div>' +
                '<div class="row calendar-row" ng-repeat="week in calendar track by $index">' +
                '<div class="col" ng-repeat="date in week track by $index" >' +
                '<div class="calendar-date" ng-click="date.canClick || clickDate(date.sDay);date.canClick || detailday()"' +
                ' ng-disabled="date.canClick" ng-if="date" ' +
                'ng-class="{blueblod: date.scheduling,current: date.isToday,select: date.isSelect,gray: date.isFuture,active: (selectDate && selectDate.indexOf(date.sDay) != -1), first: first == date.sDay, last: last == date.sDay, \'in-selection\': first <= date.sDay && date.sDay <= last, disabled: (maxDate && maxDate < date.sDay) || (minDate && minDate > date.sDay)}">' +
                '<div class="{{date.tagTop}}"></div>' +
                '{{date.sDay}}' +
                '</div>' +
                '<div class="calendar-s"><div class="calendar-color-gray">{{date.tagBottom}}</div></div>' +
                '</div></div>' +
                '</div>',
                scope: {
                    year: '=?',
                    month: '=?',
                    date: '=',
                    selectDay: '=',
                    hideDay: '=',
                    hideTitle: '=',
                    onChange: '&',
                    weekFormat: '=?',
                    minDate: '=?',
                    maxDate: '=?',
                    selectDate: '=',
                    first: '=?',
                    last: '=?',
                    multiSelect: '=',
                    detailday: '&',
                    scheduling: '=',  // 蓝色加粗blueblod
                    tagBottom: '=',
                    tagTop: '=',
                    dateFlag: '='
                },
                controller: ['$scope', '$rootScope', '$element', '$mePerpetualCalendar', '$timeout', function($scope, $rootScope, $element, $mePerpetualCalendar, $timeout) {
                    var self = this,
                        nowDate = new Date(),
                        i;
                    self.scope = $scope;
                    $scope.self = self;
                    $scope.clickDate = function(inDay) {
                        $rootScope.selectDay = inDay;

                        angular.forEach(self.calendar, function(d) {
                            d.isSelect = false;
                        });

                        if (self.calendar[inDay - 1] !== undefined) {
                            self.calendar[inDay - 1].isSelect = true;
                        }
                    };
                    /**
                     * 初始化日历
                     * @param year
                     * @param month
                     */
                    self.setCalendar = function(year, month) {
                        year = angular.isNumber(year) ? year : nowDate.getFullYear();
                        month = angular.isNumber(month) ? month : nowDate.getMonth();

                        self.calendar = new $mePerpetualCalendar.Calendar(year, month);

                        var firstDay = self.calendar[0].week;
                        $rootScope.arr = self.calendar;
                        $scope.calendar = [];

                        if (firstDay) {
                            var firstWeek = [];

                            for (i = 0; i < firstDay; i = i + 1) {
                                firstWeek.push(null);
                            }
                            $scope.calendar.push(firstWeek);
                        } else {
                            $scope.calendar[0] = [];
                        }
                        var weekCount = 0,
                            lastWeek = $scope.calendar[0],
                            now = new Date(),
                            year = now.getFullYear(), // 年
                            month = now.getMonth() + 1, // 月
                            day = now.getDate(), // 日
                            nowTime = year * 10000 + month * 100 + day;

                        angular.forEach(self.calendar, function(d, index) {

                            // 是否该日期大于当前日期
                            if (nowTime < d.sYear * 10000 + d.sMonth * 100 + d.sDay) {
                                d.isFuture = true;
                            }
                            // 排班日期
                            if ($scope.scheduling !== undefined) {
                                for (var i = 0; i < $scope.scheduling.length; i++) {
                                    if (parseInt($scope.scheduling[i], 10) == d.sDay) {
                                        d.scheduling = true;
                                        d.canClick = false;
                                        break;
                                    }
                                }
                            }
                            //  出勤时长text显示，也可以是节日，在日期的底部
                            if ($scope.tagBottom !== undefined) {
                                for (var k = 0; k < $scope.tagBottom.length; k = k + 1) {
                                    if (parseInt($scope.tagBottom[k].date, 10) == d.sDay) {
                                        d.tagBottom = $scope.tagBottom[k].val;
                                        break;
                                    }
                                }
                            }
                            // 显示 请假，异常的信息，在日期的右上角
                            if ($scope.tagTop !== undefined) {
                                for (var n = 0; n < $scope.tagTop.length; n = n + 1) {
                                    if (parseInt($scope.tagTop[n].date, 10) == d.sDay) {
                                        d.tagTop = 'calendar-top-' + $scope.tagTop[n].val;
                                        break;
                                    }
                                }
                            }

                            if (lastWeek.length < 7) {
                                lastWeek.push(d);
                            } else {
                                weekCount += 1;
                                lastWeek = [d];
                                $scope.calendar.push(lastWeek);
                            }
                        });
                        for (i = lastWeek.length; i < 7; i = i + 1) {
                            lastWeek.push(null);
                        }
                    };
                }],
                compile: function($element) {
                    $element.find('.calendar').css('max-width', angular.element('body').width());
                    return function($scope, $element, $attr, ctrls) {
                        var ctrl = ctrls[0];

                        $scope.$watch('weekFormat', function(weekFormat) {
                            if (!angular.isFunction(weekFormat)) {
                                $scope.weekFormat = function(w) {
                                    return ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][w];
                                };
                            }
                        });

                        $scope.$watch('selectDate', function(selectDate) {
                            if (angular.isNumber(selectDate) || angular.isString(selectDate)) {
                                $scope.selectDate = [selectDate];
                            }
                        });

                        $scope.$watch('year', function(year) {
                            if (angular.isNumber($scope.month)) {
                                ctrl.setCalendar(year, $scope.month);
                            }
                        });

                        $scope.$watch('month', function(month) {
                            if (angular.isNumber($scope.year)) {
                                ctrl.setCalendar($scope.year, month);
                            }
                        });

                        $scope.$watch('tagBottom', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });
                        $scope.$watch('scheduling', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });

                        $scope.$watch('tagTop', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });
                        $scope.$watch('dateFlag', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });

                        $scope.pickDate = function(date) {
                            if (date >= $scope.minDate && date <= $scope.maxDate) {
                                $scope.onChange.call($scope, {
                                    $event: [$scope.year, $scope.month, date]
                                });
                            }
                        };
                    };
                }
            };
        }])
        .directive('meCalender', [function() {
            return {
                restrict: 'E',
                require: ['meCalender'],
                template: '<div class="calendar">' +
                '<div class="calendar-title" ng-if="!hideDay"></div>' +
                '<div class="row calendar-week" ng-if="!hideDay"><div class="col" ng-repeat="w in [0,1,2,3,4,5,6]">{{weekFormat(w)}}</div></div>' +
                '<div class="row calendar-row" ng-repeat="week in calendar track by $index">' +
                '<div class="col" ng-repeat="date in week track by $index" >' +
                '<div class="calendar-date" ng-click="date.canClick || clickDate(date.sDay);date.canClick || detailday()"' +
                ' ng-disabled="date.canClick" ng-if="date" ' +
                'ng-class="{black: date.scheduling,current: date.isToday,select: date.isSelect,gray: date.isFuture,active: (selectDate && selectDate.indexOf(date.sDay) != -1), first: first == date.sDay, last: last == date.sDay, \'in-selection\': first <= date.sDay && date.sDay <= last, disabled: (maxDate && maxDate < date.sDay) || (minDate && minDate > date.sDay)}">' +
                '<div class="{{date.tagTop}}"></div>' +
                '{{date.sDay}}' +
                '</div>' +
                '<div class="calendar-s"><div class="calendar-color-gray">{{date.tagBottom}}</div></div>' +
                '</div></div>' +
                '</div>',
                scope: {
                    year: '=?',
                    month: '=?',
                    date: '=',
                    selectDay: '=',
                    hideDay: '=',
                    hideTitle: '=',
                    onChange: '&',
                    weekFormat: '=?',
                    minDate: '=?',
                    maxDate: '=?',
                    selectDate: '=',
                    first: '=?',
                    last: '=?',
                    multiSelect: '=',
                    detailday: '&',
                    scheduling: '=', // 蓝色加粗blueblod
                    tagBottom: '=',
                    tagTop: '=',
                    dateFlag: '='
                },
                controller: ['$scope', '$rootScope', '$element', '$mePerpetualCalendar', '$timeout', function($scope, $rootScope, $element, $mePerpetualCalendar, $timeout) {
                    var self = this,
                        nowDate = new Date(),
                        i;
                    self.scope = $scope;
                    $scope.self = self;
                    $scope.clickDate = function(inDay) {
                        $rootScope.selectDayIndex = inDay;

                        angular.forEach(self.calendar, function(d) {
                            d.isSelect = false;
                        });

                        if (self.calendar[inDay - 1] !== undefined) {
                            self.calendar[inDay - 1].isSelect = true;
                        }
                        $scope.$evalAsync();
                    };
                    /**
                     * 初始化日历
                     * @param year
                     * @param month
                     */
                    self.setCalendar = function(year, month) {
                        year = angular.isNumber(year) ? year : nowDate.getFullYear();
                        month = angular.isNumber(month) ? month : nowDate.getMonth();

                        self.calendar = new $mePerpetualCalendar.Calendar(year, month);

                        var firstDay = self.calendar[0].week;
                        $rootScope.arr = self.calendar;
                        $scope.calendar = [];

                        if (firstDay) {
                            var firstWeek = [];

                            for (i = 0; i < firstDay; i = i + 1) {
                                firstWeek.push(null);
                            }
                            $scope.calendar.push(firstWeek);
                        } else {
                            $scope.calendar[0] = [];
                        }
                        var weekCount = 0,
                            lastWeek = $scope.calendar[0],
                            now = new Date(),
                            year = now.getFullYear(), // 年
                            month = now.getMonth() + 1, // 月
                            day = now.getDate(), // 日
                            nowTime = year * 10000 + month * 100 + day;

                        angular.forEach(self.calendar, function(d, index) {

                            // 是否该日期大于当前日期
                            if (nowTime < d.sYear * 10000 + d.sMonth * 100 + d.sDay) {
                                d.isFuture = true;
                            }
                            // 排班日期
                            if ($scope.scheduling !== undefined) {
                                for (var i = 0; i < $scope.scheduling.length; i++) {
                                    if (parseInt($scope.scheduling[i], 10) == d.sDay) {
                                        d.scheduling = true;
                                        d.canClick = false;
                                        break;
                                    }
                                }
                            }
                            //  出勤时长text显示，也可以是节日，在日期的底部
                            if ($scope.tagBottom !== undefined) {
                                for (var k = 0; k < $scope.tagBottom.length; k = k + 1) {
                                    if (parseInt($scope.tagBottom[k].date, 10) == d.sDay) {
                                        d.tagBottom = $scope.tagBottom[k].val;
                                        break;
                                    }
                                }
                            }
                            // 显示 请假，异常的信息，在日期的右上角
                            if ($scope.tagTop !== undefined) {
                                for (var n = 0; n < $scope.tagTop.length; n = n + 1) {
                                    if (parseInt($scope.tagTop[n].date, 10) == d.sDay) {
                                        d.tagTop = 'calendar-top-' + $scope.tagTop[n].val;
                                        break;
                                    }
                                }
                            }

                            if (lastWeek.length < 7) {
                                lastWeek.push(d);
                            } else {
                                weekCount += 1;
                                lastWeek = [d];
                                $scope.calendar.push(lastWeek);
                            }
                        });
                        for (i = lastWeek.length; i < 7; i = i + 1) {
                            lastWeek.push(null);
                        }
                    };

                    $rootScope.$on('selectDayIndex',function (event, inDay) {
                        if (angular.isNumber(parseInt(inDay))) {
                            setTimeout(function () {
                                if (self.calendar[parseInt(inDay) - 1] !== undefined) {
                                    self.calendar[parseInt(inDay) - 1].isSelect = true;
                                } else {
                                    self.calendar[0].isSelect = true;
                                }
                                $scope.$evalAsync();
                            }, 20);

                        }
                    });
                }],
                compile: function($element) {
                    $element.find('.calendar').css('max-width', angular.element('body').width());
                    return function($scope, $element, $attr, ctrls) {
                        var ctrl = ctrls[0];

                        $scope.$watch('weekFormat', function(weekFormat) {
                            if (!angular.isFunction(weekFormat)) {
                                $scope.weekFormat = function(w) {
                                    return ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][w];
                                };
                            }
                        });

                        $scope.$watch('selectDate', function(selectDate) {
                            if (angular.isNumber(selectDate) || angular.isString(selectDate)) {
                                $scope.selectDate = [selectDate];
                            }
                        });
                        $scope.$watch('year', function(year) {
                            if (angular.isNumber($scope.month)) {
                                ctrl.setCalendar(year, $scope.month);
                            }
                        });

                        $scope.$watch('month', function(month) {
                            if (angular.isNumber($scope.year)) {
                                ctrl.setCalendar($scope.year, month);
                            }
                        });

                        $scope.$watch('tagBottom', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });
                        $scope.$watch('scheduling', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });

                        $scope.$watch('tagTop', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });
                        $scope.$watch('dateFlag', function() {
                            ctrl.setCalendar($scope.year, $scope.month);
                        });

                        $scope.pickDate = function(date) {
                            if (date >= $scope.minDate && date <= $scope.maxDate) {
                                $scope.onChange.call($scope, {
                                    $event: [$scope.year, $scope.month, date]
                                });
                            }
                        };
                    };
                }
            };
        }]);
});
