define(['ionic'], function() {
    return [
        '$scope', 'cService', 'log', '$rootScope', '$state', '$timeout', '$daggerToast', 'widgetFactory', '$ionicPopover', '$ionicTabsDelegate', '$stateParams', '$ionicScrollDelegate',
        function($scope, cService, log, $rootScope, $state, $timeout, $daggerToast, widgetFactory, $ionicPopover, $ionicTabsDelegate, $stateParams, $ionicScrollDelegate) {
            var now = new Date();
            var allMonth = now.getFullYear() * 12 + now.getMonth();
            var monthLength = 1;

            $scope.views = {
                currentYear: now.getFullYear(),
                currentMonth: now.getMonth(),
                currentDay: now.getDate(),
                startTime: '',
                endTime: '',
                tagBottom: [], //日历下面显示文字 出勤时长或者节日
                tagTop: [], //日历中标示的图标 calendar-top- 样式
                scheduling: [], //  区别排班和不排班，体现日期的字体颜色，和可点击
                selectDay: 1, // 点击当天日排班详情


                totalDays: 0, //出勤天数
                totalHours: 0, //出勤总小时
                holidayHours: 0, //请假时长
                exceptionDay: 0, //异常天数
                absentDay: 0, //旷工天数

                schedulingData: [], // 排班列表
                signData: [], // 打卡列表
                exceptionData: [], // 异常列表
            };
            $scope.ctrl = {
                isCalendarPre: true,
                isCalendarNext: false,
                tabType: 1,
                popover: null,
                dayList: [],
                selectDay: '',
                attendType: 0
            };
            $scope.AttendanceList = []; //获取到的考勤记录处理后的结果
            $rootScope.selectDayIndex = 1;

            function calculateMonth(date, type) {
                var day = date.getDate() <= 9 ? '0' + date.getDate() : '' + date.getDate(),
                    mon = (date.getMonth() + 1) <= 9 ? '0' + (date.getMonth() + 1) : '' + (date.getMonth() + 1),
                    year = date.getFullYear();
                if (type === 'year') {
                    return year;
                } else if (type === 'month') {
                    return year + mon;
                } else if (type === 'date') {
                    return year + mon + day;
                }
            }

            function calculateCurrentMonth() {
                var yearMonth = $scope.views.currentYear + '' + (($scope.views.currentMonth + 1) > 9 ? ($scope.views.currentMonth + 1) : '0' + ($scope.views.currentMonth + 1));
                var list = $scope.AttendanceList[yearMonth];
                $scope.views.totalDays = 0;
                $scope.views.totalHours = 0;
                $scope.views.holidayHours = 0;

                $scope.views.tagBottom = [];
                $scope.views.tagTop = [];
                $scope.views.scheduling = [];

                var totalDays = 0,
                    totalHours = 0,
                    holidayHours = 0,
                    dayList = [];
                angular.forEach(list, function(item, index) {
                    // 出勤天数、小时、请假时长计算
                    if (parseFloat(item.onhours) > 0) {
                        totalDays++;
                        totalHours += parseFloat(item.onhours);
                    }

                    // 请假计算
                    if (parseFloat(item.leavetime) > 0) {
                        holidayHours += parseFloat(item.leavetime);
                    }


                    // 日历信息配置
                    var day = (new Date(item.Date)).getDate();
                    var hours = 0;
                    if(item.onhours){
                        hours = hours + parseFloat(item.onhours);
                    }
                    if(item.overtime){
                        hours = hours + parseFloat(item.overtime);
                    }
                    $scope.views.tagBottom.push({
                        date: day,
                        val: hours == 0 ? '' : hours + 'h'
                    });

                    var tagTopFlag = 0;
                    if ('' !== item.daynote.trim()) {
                        tagTopFlag = 2;
                    } else if (parseFloat(item.overtime) > 0) {
                        tagTopFlag = 3;
                    } else if (parseFloat(item.leavetime) > 0) {
                        tagTopFlag = 1;
                    }
                    $scope.views.tagTop.push({
                        date: day,
                        val: tagTopFlag
                    });
                    if (parseFloat(item.ontime) > 0) {
                        $scope.views.scheduling.push(day);
                    }

                    // 排序
                    var sLength = dayList.length,
                        day = parseInt(item.Date.split('-')[2]),
                        monthDays = (new Date($scope.views.currentYear, $scope.views.currentMonth + 1, 0)).getDate();

                    if (sLength !== 0) {
                        if (dayList[day - 1]) {
                            dayList[day - 1].list.push(item)
                        } else {
                            dayList[day - 1] = {
                                Date: item.Date,
                                list: [item]
                            };
                        }
                    } else {
                        dayList = new Array(monthDays);
                        dayList[0] = {
                            Date: item.Date,
                            list: [item]
                        };
                    }
                });
                $scope.ctrl.dayList = dayList;
                $scope.views.totalDays = totalDays;
                $scope.views.totalHours = totalHours;
                $scope.views.holidayHours = holidayHours;


                var now = new Date();
                if (now.getFullYear() == $scope.views.currentYear && now.getMonth() === $scope.views.currentMonth) {
                    $rootScope.selectDayIndex = $scope.views.currentDay;
                    $scope.ctrl.selectDay = $scope.ctrl.dayList[$rootScope.selectDayIndex - 1];
                    $rootScope.$emit('selectDayIndex', $rootScope.selectDayIndex);
                } else {
                    $scope.ctrl.selectDay = $scope.ctrl.dayList[$rootScope.selectDayIndex - 1];
                    $rootScope.$emit('selectDayIndex', $rootScope.selectDayIndex);
                }

            }

            /**
             * 按月区分数据
             *
             * @param list
             */
            function calculateData(list) {
                $scope.views.exceptionDay = 0;
                $scope.views.absentDay = 0;

                $scope.AttendanceList = [];

                var schedulingData = [],
                    signData = [],
                    exceptionData = [],
                    attendanceList = {},
                    exceptionDay = 0,
                    absentDay = 0,
                    date = '',
                    yearMonth = '',
                    sLength;
                angular.forEach(list, function(item, index) {
                    if(item.Date) {
                        date = item.Date.split('-');
                        yearMonth = date[0] + date[1];

                        if (!attendanceList[yearMonth]) {
                            attendanceList[yearMonth] = [];
                            attendanceList[yearMonth].push(item)
                        } else {
                            attendanceList[yearMonth].push(item)
                        }
                        // 排班处理
                        sLength = schedulingData.length;

                        if (sLength !== 0 && schedulingData[sLength - 1].Date === item.Date) {
                            schedulingData[sLength - 1].ShiftTime.push(item.ShiftTime);
                            schedulingData[sLength - 1].ontime += parseFloat(item.ontime);

                        } else {
                            schedulingData.push({
                                Date: item.Date,
                                ShiftTime: [item.ShiftTime],
                                ontime: parseFloat(item.ontime ? item.ontime : 0)
                            });
                        }

                        // 打卡处理
                        sLength = signData.length;

                        if (sLength !== 0 && signData[sLength - 1].Date === item.Date) {

                            if (item.StarDate || item.EndDate) {
                                signData[sLength - 1].signRecode.push({
                                    StarDate: item.StarDate ? item.StarDate : '无',
                                    EndDate: item.EndDate ? item.EndDate : '无'
                                });
                                signData[sLength - 1].onhours += parseFloat(item.onhours);
                            }
                        } else {
                            if (item.StarDate || item.EndDate) {
                                signData.push({
                                    Date: item.Date,
                                    signRecode: [{
                                        StarDate: item.StarDate ? item.StarDate : '无',
                                        EndDate: item.EndDate ? item.EndDate : '无'
                                    }],
                                    onhours: parseFloat(item.onhours ? item.onhours : 0)
                                });
                            }
                        }
                        // 异常处理
                        sLength = exceptionData.length;
                        if (sLength !== 0 && exceptionData[sLength - 1].Date === item.Date) {
                            // 不处理
                        } else {
                            // 旷工算一天
                            if (parseFloat(item.absenttime) > 0) {
                                absentDay++;
                            }

                            if (parseFloat(item.absenttime) > 0 || parseFloat(item.LateMin) > 0 || parseFloat(item.EarlyMin) > 0) {
                                //旷工，迟到，早退算是一天异常
                                exceptionDay++;
                            }
                        }

                        if (parseFloat(item.absenttime) > 0 || parseFloat(item.LateMin) > 0 || parseFloat(item.EarlyMin) > 0) {
                            exceptionData.push({
                                Date: item.Date,
                                absenttime: item.absenttime,
                                LateMin: item.LateMin,
                                EarlyMin: item.EarlyMin,
                                signRecode: {
                                    StarDate: item.StarDate ? item.StarDate : '无',
                                    EndDate: item.EndDate ? item.EndDate : '无'
                                },
                                daynote: item.daynote,
                            });
                        }
                    }
                });

                //排班，打卡，异常列表设值
                $scope.views.schedulingData = schedulingData;
                $scope.views.signData = signData;
                $scope.views.exceptionData = exceptionData;
                // 异常天数，旷工天数设值
                $scope.views.exceptionDay = exceptionDay;
                $scope.views.absentDay = absentDay;
                // 按月 数据存储设值
                $scope.AttendanceList = attendanceList;
                calculateCurrentMonth()
            }

            /**
             * 日历信息获取  ， 15之前获取2个月的，15号之后获取一个月的
             * @param  {[String]} userId 用户id
             */
            function getCalendar(userId) {
                if (now.getDate() <= 15) {
                    $scope.ctrl.isCalendarPre = true;
                    var startTime = calculateMonth(new Date(now.getFullYear(), now.getMonth() - 1), 'month') + '01';
                } else {
                    $scope.ctrl.isCalendarPre = false;
                    var startTime = calculateMonth(now, 'month') + '01';
                }

                var endTime = calculateMonth(new Date(now.getFullYear(), now.getMonth() + 1, 0), 'date');

                $scope.views.startTime = startTime.substr(0, 4) + '年' + startTime.substr(4, 2) + '月' + startTime.substr(6, 2) + '日';
                $scope.views.endTime = endTime.substr(0, 4) + '年' + endTime.substr(4, 2) + '月' + endTime.substr(6, 2) + '日';

                cService.getAttendanceList(startTime, endTime, userId).then(function(res) {
                    if (res && res.length > 0) {
                        res = cService.xmlToJson2(res, 'Table');
                        // 本月排班信息
                        calculateData(res);
                    }
                }, function(res) {
                    if (-1 === res) {
                        $daggerToast.show('月考勤登录过期，请退出重新进入！');
                    }
                });
            };
            /**
             * 打开菜单
             */
            $scope.openMenu = function(e) {
                $ionicPopover.fromTemplateUrl('popover.html', {
                    scope: $scope
                }).then(function(popover) {
                    $scope.popover = popover;
                    $scope.popover.show(e);
                });
            };
            $scope.openMenu2 = function(e) {
                var target = document.getElementById('openMenu');
                $scope.openMenu(target);
            };
            /**
             * 点击菜单项
             */
            $scope.flowSelect = function(state) {
                $scope.popover.hide();
                // $state.go(state);
                $state.go(state);
            };

            /**
             * 点击日历切换月份
             */
            $scope.changeMonth = function(flag) {
                var months = null,
                    d;
                if ($scope.ctrl.isCalendarNext && !flag) {
                    d = new Date($scope.views.currentYear, $scope.views.currentMonth + 1, 1);
                    $scope.views.currentYear = d.getFullYear();
                    $scope.views.currentMonth = d.getMonth();
                }
                if ($scope.ctrl.isCalendarPre && flag) {
                    d = new Date($scope.views.currentYear, $scope.views.currentMonth - 1, 1);
                    $scope.views.currentYear = d.getFullYear();
                    $scope.views.currentMonth = d.getMonth();
                }

                if (d) {
                    months = d.getFullYear() * 12 + d.getMonth();
                    if (months === allMonth) {
                        $scope.ctrl.isCalendarNext = false;
                        $scope.ctrl.isCalendarPre = true;
                    } else if (months === allMonth - monthLength) {
                        $scope.ctrl.isCalendarNext = true;
                        $scope.ctrl.isCalendarPre = false;
                    } else if (months > allMonth - monthLength && months < allMonth) {
                        $scope.ctrl.isCalendarNext = true;
                        $scope.ctrl.isCalendarPre = true;
                    }
                    // 调用接口获取数据
                    //getCalendar('80017336');
                    //getCalendar($stateParams.pernr);
                    calculateCurrentMonth();
                }
            };
            /**
             * 点击日历按钮
             */
            $scope.clickDate = function() {
                $scope.ctrl.selectDay = $scope.ctrl.dayList[$rootScope.selectDayIndex - 1];

                $ionicScrollDelegate.$getByHandle('calender').resize();
            };

            $scope.getStatus = function(item) {
                /*{
                 Date: "2017-05-01",EarlyMin: "0",EmpID: "80000007",EndDate: "00:00",
                 ErrorMsg: "",IsLegal: "0",LateMin: "0",
                 RecordID: "1abc9c5e-d999-42c4-887b-cf65f0dbec7d",
                 ShiftNme: "法定节日班",ShiftTime: "00:00-00:00",StarDate: "00:00",
                 absenttime: "0.00",daynote: "",leavename: "",leavetime: "0.00",
                 movertime: "0.00",onhours: "8.00",ontime: "8.00",overtime: "0.00"
                 }*/
                /*
                 ctrl.attendType: 0：正常、加班 1：漏刷卡、旷工 2：请假 4：迟到、早退
                 */
                if (item.daynote) {
                    if ((item.daynote.indexOf('漏刷卡') != -1) || (item.daynote.indexOf('旷工') != -1)) {
                        $scope.ctrl.attendType = 1;
                    } else {
                        $scope.ctrl.attendType = 4;
                    }
                    return item.daynote;
                    /*if ((item.daynote.indexOf('漏刷卡') != -1) || (item.daynote.indexOf('旷工') != -1)) {
                     return '<span class="yellow">' + item.daynote + '</span><div class="btn-handle">请处理<i class="ion-ios-arrow-right"></i></div>';
                     } else {
                     return '<span class="yellow">' + item.daynote + '</span>';
                     }*/
                } else if (item.leavename) {
                    $scope.ctrl.attendType = 2;
                    return item.leavename;
                } else if (parseFloat(item.leavetime) > 0) {
                    $scope.ctrl.attendType = 2;
                    return '请假 ' + item.leavetime + '小时';
                } else if (parseFloat(item.overtime) > 0) {
                    $scope.ctrl.attendType = 0;
                    return '加班 ' + item.overtime + '小时';
                } else if (item.ShiftTime == '00:00-00:00') {
                    $scope.ctrl.attendType = 0;
                    return item.ShiftNme;
                } else {
                    $scope.ctrl.attendType = 0;
                    return '正常打卡';
                }
            };

            $scope.activeNowdate = function(d) {
                var now = new Date(),
                    currentDate = new Date(d);
                if((now.getFullYear() == currentDate.getFullYear()) && (now.getMonth() + 1 == currentDate.getMonth()) && (now.getDate() == currentDate.getDate())) {
                    return 'current'
                } else {
                    return ''
                }
            };

            function init() {
                cService.getUser().then(function (user) {
                    getCalendar(user.uid);
                });
            }
            init();
        }
    ];
});
