/**
 * Created  by Administrator on 14-12-29.
 */
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        'picture',
        '$timeout',
        function($scope, cService, log, $rootScope, $stateParams, picture, $timeout) {
            var tag = false;

            $scope.views = {};

            $scope.ctrl = {};

            $scope.selectPerson = function () {
                cordova.exec(function (success) {
                    alert(JSON.stringify(success));
                }, function (error) {
                    alert("Error: " + error);
                }, "Organization", "fetchDepart", [{"withChild": true, "withUser": true,"departId": "1366201679-10000029"}]);
            };
            $scope.selectPerson2 = function () {
                var url = 'https://hr.yh-test.com/mas-api/proxy?alias=sharegoo.attend.detail&arg0=ctx2hv55yatccl55zbirfqrm&arg1=%26lt;?xml%20version=%26quot;1.0%26quot;%20encoding=%26quot;utf-8%26quot;%20?%26gt;%26lt;DocumentElement%26gt;%26lt;Table%26gt;%26lt;empid%26gt;80000007%26lt;/empid%26gt;%26lt;begindate%26gt;20170501%26lt;/begindate%26gt;%26lt;enddate%26gt;20170531%26lt;/enddate%26gt;%26lt;/Table%26gt;%26lt;/DocumentElement%26gt;';

                cService.request(url,{},{method:'get'}).then(function (respondData) {
                    console.log(respondData);
                    if (respondData) {
                        var xml = cService.parseXML(respondData.substring(39));
                            var list = cService.xmlToJson2(respondData, 'Table');
                            console.log(list);
                    }
                })
            };

            function init() {
                log('详细');
            }
            init();
            $scope.$apply();
        }
    ];
});
