/**
 * Created  by Administrator on 14-12-29.
 */
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        'picture',
        '$timeout',
        '$ionicModal',
        '$ionicPopup',
        '$daggerToast',
        'widgetFactory',
        '$daggerSearch',
        function($scope, cService, log, $rootScope, $stateParams, picture, $timeout, $ionicModal, $ionicPopup, $daggerToast, widgetFactory, $daggerSearch) {
            $scope.views = {
                moveshiftList: [],
                searchText: '',
            };

            $scope.ctrl = {
                modal: null,
                modal2: null,
                moveshiftsModal: null,
                fdMoveReason: '',
                moveworkinfolist: [], // 调班明细
                moveworkinfo: {},
                moveworkpeoplelist: [], // 接班人
                moveworkpeople: {}
            };

            $scope.clearText = function () {
                $scope.views.searchText = '';
            };
            /**
             * 调班说明弹窗
             */
            $scope.popupDesc = function() {
                $ionicPopup.alert({
                    title: '调班说明',
                    template: '<p>1.对于有些大区如：华西大区、福建大区目前有部分为合伙人团队的（有合伙人、全职工的）也有红标职级的全部按两种职级统计。</p><p>2.年平均收入（=应发-考勤扣款）统计人员规则：必须满足全年12个月有收入人员，即整年有在职的，不含年终奖。</p><p>3.年同比费用增长=当年费用汇总-上年费用汇总</p><p>4.年同比费用涨幅（=（当年费用汇总-上年费用汇总）/上年费用汇总*100%）</p><p>5.部门人均收入（= 部门总费用/部门总人数）</p>',
                    cssClass: 'moveshift-popup',
                    okText: '我知道了'
                });
            };

            function setMovework(prop, uid) {
                cService.getAttendanceList($scope.ctrl.moveworkinfo.fdDate, $scope.ctrl.moveworkinfo.fdDate, uid).then(function(res) {
                    /*res = [{
                        Date: "2017-09-01",
                        EarlyMin: "0",
                        EmpID: "80086534",
                        EndDate: "22:01",
                        ErrorMsg: "",
                        IsLegal: "0",
                        LateMin: "0",
                        RecordID: "f4bd5eb1-516a-4278-8c14-ffaa15f3dbcc",
                        ShiftNme: "HX/I/I016",
                        ShiftTime: "13:30-22:00",
                        StarDate: "13:17",
                        absenttime: "0.00",
                        daynote: "",
                        leavetime: "0.00"
                    }];*/
                    res = cService.xmlToJson2(res, 'Table');
                    $scope.ctrl[prop].fdName = res[0].ShiftNme;
                    $scope.ctrl[prop].fdWorktime = res[0].ShiftTime;
                    console.log(res);
                    if (res.length > 1) {
                        $scope.ctrl[prop].fdWorktimeSecond = res[1].ShiftTime;
                        $scope.ctrl[prop].fdWorktimeLong = parseFloat(res[0].ontime) + parseFloat(res[1].ontime);
                    } else if (res.length === 1) {
                        if (res[0].Date && res[0].IsLegal == 0) {
                            $scope.ctrl[prop].fdWorktimeLong = res[0].ontime;
                        } else if(res[0].IsLegal == 1){
                            $daggerToast.show(res[0].ErrorMsg);
                        } else {
                            $daggerToast.show('当天无排班，无法调班！');
                        }
                    } else {
                        $daggerToast.show('当天无排班，无法调班！');
                    }
                });
            }
            // 选择现有班次
            $scope.selectShift = function(moveworkpeople, selectName) {
                if (CONFIGURATION.com.midea.isPcTest) {
                    var newDate = new Date();
                    if (moveworkpeople) {
                        // 接班人
                        if (selectName === 1) {
                            $scope.ctrl.moveworkpeople.fdPeopleJobNum = '80559735'; // 接班人工号
                            $scope.ctrl.moveworkpeople.fdPeoplename = '孙莉'; // 接班人姓名
                            if ($scope.ctrl.moveworkpeople.fdDate) {
                                setMovework('moveworkpeople', $scope.ctrl.moveworkpeople.fdPeopleJobNum);
                            }
                        } else {
                            $scope.ctrl.moveworkpeople.fdDate = cService.dateFormat(newDate);
                            if ($scope.ctrl.moveworkpeople.fdPeopleJobNum) {
                                setMovework('moveworkpeople', $scope.ctrl.moveworkpeople.fdPeopleJobNum);
                            }
                        }
                    } else {
                        // 调班明细
                        $scope.ctrl.moveworkinfo.fdDate = cService.dateFormat(newDate);
                        cService.getUser().then(function(res) {
                            setMovework('moveworkinfo', res.uid);
                        });
                    }
                } else {
                    widgetFactory.showPicker({
                        date: new Date(),
                        mode: 'date',
                        type: 'day'
                    }).then(function(newDate) {
                        if (moveworkpeople) {
                            // 接班人
                            if (selectName === 1) {
                                widgetFactory.orgChoose().then(function(res) {
                                    if (res.result) {
                                        $scope.ctrl.moveworkpeople.fdPeopleJobNum = res.array[0].uid; // 接班人工号
                                        $scope.ctrl.moveworkpeople.fdPeoplename = res.array[0].positionname; // 接班人姓名
                                        if ($scope.ctrl.moveworkpeople.fdDate) {
                                            setMovework('moveworkpeople', res.array[0].uid);
                                        }
                                    }
                                })
                            } else {
                                $scope.ctrl.moveworkpeople.fdDate = cService.dateFormat(newDate);
                                if ($scope.ctrl.moveworkpeople.fdPeopleJobNum) {
                                    setMovework('moveworkpeople', $scope.ctrl.moveworkpeople.fdPeopleJobNum);
                                }
                            }
                        } else {
                            // 调班明细
                            $scope.ctrl.moveworkinfo.fdDate = cService.dateFormat(newDate);
                            cService.getUser().then(function(res) {
                                setMovework('moveworkinfo', res.uid);
                            });
                        }
                    });
                }
            };
            // 点击添加调班明细
            $scope.addDetail = function(index, item) {
                $scope.ctrl.moveworkinfo = {
                    fdName: '', // 现有班次名称
                    fdMovename: '', // 调换班次名称
                    fdWorktime: '', // 现有班次时间
                    fdWorktimeSecond: '', // 现有班次时间2
                    fdWorktimeLong: '', // 现有班次时间总时长
                    fdMoveworktime: '', // 调换班次时间
                    fdMoveworktimeSecond: '', // 调换班次时间2
                    fdMoveworktimeLong: '', // 调换班次时间时长
                    fdMoveworkreson: '', // 调班原因
                    fdDate: '', // 调班日期
                    fdNoAtPerson: '', // 不在岗负责人姓名
                    fdNoAtNo: '', // 不在岗负责人工号
                    fdWorkNum: '', // 现有班次ID
                    fdMoveWorkNum: '' // 调换班次ID
                };
                $scope.ctrl.modal.show();
            };
            // 确定添加调班明细
            $scope.confirmAddMovework = function() {
                if (!$scope.ctrl.moveworkinfo.fdDate) {
                    $daggerToast.show('请选择调班日期');
                } else if (!$scope.ctrl.moveworkinfo.fdName) {
                    $daggerToast.show('请选择现有班次');
                } else if (!$scope.ctrl.moveworkinfo.fdMovename) {
                    $daggerToast.show('请选择调换班次');
                }
                /* else if (!$scope.ctrl.moveworkinfo.fdNoAtNo) {
                                    $daggerToast.show('请选择不在岗负责人');
                                }*/
                else {
                    $scope.ctrl.moveworkinfolist.push($scope.ctrl.moveworkinfo);
                    $scope.ctrl.modal.hide();
                }
            };
            // 删除调班明细
            $scope.deleteMovework = function(index) {
                $scope.ctrl.moveworkinfolist.splice(index, 1);
            };
            // 编辑调班明细
            $scope.editMovework = function(index) {
                $scope.ctrl.moveworkinfo = $scope.ctrl.moveworkinfolist[index];
                $scope.ctrl.modal.show();
            };
            $scope.selectMoveShift = function(item) {

            };
            /*$scope.selectNoAtPerson = function() {
                if (CONFIGURATION.com.midea.isPcTest) {
                    $scope.ctrl.moveworkinfo.fdNoAtNo = '80602426';
                    $scope.ctrl.moveworkinfo.fdNoAtPerson = '陈璐'; // 不在岗负责人姓名
                } else {
                    widgetFactory.orgChoose().then(res => {
                        if (res.result) {
                            $scope.ctrl.moveworkinfo.fdNoAtNo = res.array[0].uid; // 不在岗负责人工号
                            $scope.ctrl.moveworkinfo.fdNoAtPerson = res.array[0].positionname; // 不在岗负责人姓名
                        }
                    })
                }
            }*/

            /*// 点击添加接班人员
            $scope.addMoveworkpeople = function() {
                $scope.ctrl.modal2.show();
                $scope.ctrl.moveworkpeople = {
                    fdName: '', // 现有班次名称,
                    fdMovename: '', // 调换班次名称,
                    fdWorktime: '', // 现有班次时间,
                    fdWorktimeSecond: '', // 现有班次时间2,
                    fdWorktimeLong: '', // 现有班次时间总时长,
                    fdMoveworktime: '', // 调换班次时间, fdMoveworktimeSecond: '', // 调换班次时间2,
                    fdMoveworktimeLong: '', // 调换班次时间时长,
                    fdDate: '', // 调班日期,
                    fdPeoplename: '', // 接班人姓名,
                    fdPeopleJobNum: '', // 接班人工号,
                    fdWorkNum: '', //  现有班次ID,
                    fdMoveWorkNum: '', //  调换班次ID
                };
            };
            // 确定添加接班人员
            $scope.confirmAddMoveworkpeople = function() {
                $scope.ctrl.moveworkpeoplelist.push($scope.ctrl.moveworkpeople);
                $scope.ctrl.modal2.hide();
            };
            // 删除接班人员
            $scope.deleteMovepeople = function(index) {
                $scope.ctrl.moveworkpeoplelist.splice(index, 1);
            };
            // 编辑接班人员
            $scope.editMovepeople = function(index) {
                $scope.ctrl.moveworkpeople = $scope.ctrl.moveworkpeoplelist[index];
                $scope.ctrl.modal2.show();
            }*/

            // 提交申请
            $scope.submitFrom = function() {
                if (!$scope.ctrl.fdMoveReason) {
                    $daggerToast.show('请先填写调班原因');
                } else if ($scope.ctrl.moveworkinfolist.length === 0) {
                    $daggerToast.show('请先添加调班明细');
                } else {
                    cService.confirm('确认发起调班申请流程？').then(function(isTrue) {
                        if (isTrue) {
                            cService.submitMoveworkApply({ fdMoveReason: $scope.ctrl.fdMoveReason, yhHrMoveworkinfolist: $scope.ctrl.moveworkinfolist, yhHrMoveworkpeoplelist: $scope.ctrl.moveworkpeoplelist }).then(function(res) {
                                if (0 == res.status) {
                                    $daggerToast.show('调班申请提交成功');
                                    /*$state.go('myapply', {
                                        applyType: 'overtime'
                                    });*/
                                    $rootScope.goBack();
                                } else {
                                    $daggerToast.show(res.desc);
                                }
                            });
                        }
                    })
                }
            };
            $scope.showSearch = function() {

                /*$daggerSearch.show({
                    templateUrl: 'template/flow/moveshiftsModal.html',
                    scope: $scope,
                    id: '#LOCAL_HISTORY_KEY@EXAMPLE_DAGGER',
                    searchText: $scope.searchText,
                    /!**
                     * 模拟搜索事件
                     * @param text
                     *!/
                    onSearch: function(text) {
                        $scope.searching = true;
                        $timeout(function() {
                            $scope.searching = false;
                            cService.commonSearch({
                                alias: 'ihr.sg.classes',
                                searchText: text,
                                userId: window.CONFIGURATION.com.midea.uidPlaceholder
                            }).then(function(data) {
                                if (data && data.code === 200 && data.data && data.data.list) {
                                    $scope.searchData = data.data.list;
                                }
                            });
                        }, 1000);
                    }
                });*/
                $scope.ctrl.modal2.show();
            };

            $scope.itemClick = function(item) {
                console.log(item);
                $scope.ctrl.moveworkinfo.fdMovename = item.FD_CLASS_NAME;
                $scope.ctrl.moveworkinfo.fdMoveworktime = item.FD_BEGIN_TIME;
                $scope.ctrl.moveworkinfo.fdMoveworktimeSecond = item.FD_END_TIME ? item.FD_END_TIME : '';
                $scope.ctrl.moveworkinfo.fdMoveworktimeLong = item.FD_ALL_TIME;

                $scope.ctrl.modal2.hide();
            };

            $scope.$watch('views.searchText', function(newText, oldText) {

                if(newText != ''){
                    $timeout(function() {
                        cService.commonSearch({
                            alias: 'ihr.sg.classes',
                            searchText: newText,
                            userId: window.CONFIGURATION.com.midea.uidPlaceholder
                        }).then(function(data) {
                            if (data && data.code === 200 && data.data && data.data.list) {
                                $scope.views.moveshiftList = data.data.list;
                            }
                        });
                    }, 1000);
                }

            });

            function init() {
                $ionicModal.fromTemplateUrl('templates/modal.html', {
                    scope: $scope
                }).then(function(modal) {
                    $scope.ctrl.modal = modal;
                });
                $ionicModal.fromTemplateUrl('templates/moveshiftsModal.html', {
                    scope: $scope
                }).then(function(modal) {
                    $scope.ctrl.modal2 = modal;
                });
            }
            init();
            $scope.$apply();
        }
    ];
});