/**
 * Created  by Administrator on 14-12-29.
 */
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        'picture',
        '$timeout',
        '$ionicModal',
        '$daggerToast',
        'widgetFactory',
        '$state',
        function($scope, cService, log, $rootScope, $stateParams, picture, $timeout, $ionicModal, $daggerToast, widgetFactory, $state) {
            $scope.views = {
                retroactiveList: [],
                retroactive: {
                    fdLateSignatureTime: null,
                    fdSgReasonName: null,
                    fdSgReasonId: null,
                    fdExplain: null,
                    picked: null
                },
                pickerSettings: {
                    lang: 'zh',
                    theme: 'ios',
                    display: 'bottom',
                    height: lib.flexible.dpr * 34, // 修正在flexible下的高度
                    showInput: false
                },
                reasons: []
            };

            $scope.ctrl = {
                modal: null,
                editIndex: null
            };
            // 提交申请
            $scope.submitFrom = function() {
                if ($scope.views.retroactiveList.length === 0) {
                    $daggerToast.show('请先添加补卡申请');
                } else {
                    cService.confirm('确认发起补卡申请流程？').then(function(isTrue) {
                        if (isTrue) {
                            console.log($scope.views.retroactive);
                            cService.submitRetroactiveApply({ fdLateSignatureInfoList: $scope.views.retroactiveList }).then(function(res) {
                                if (1 == res.errorcode) {
                                    $daggerToast.show('补卡申请提交成功');
                                    /*$state.go('myapply', {
                                        applyType: 'retroactive'
                                    });*/
                                    $rootScope.goBack();
                                } else {
                                    $daggerToast.show(res.errormsg);
                                }
                            });
                        }
                    })
                }
            };
            // 删除补卡申请
            $scope.deleteApply = function(index) {
                // 删除
                $scope.views.retroactiveList.splice(index, 1);
            }
            // 编辑补卡申请
            $scope.editApply = function(index, item) {
                $scope.ctrl.editIndex = index;
                $scope.views.retroactive = item;
                $scope.ctrl.modal.show();
            };
            // 选中请假类型
            $scope.selectReason = function() {
                $scope.ctrl.myInstance.show();
            };
            // 添加补卡申请
            $scope.addApply = function() {
                $scope.views.retroactive = {
                    fdLateSignatureTime: null,
                    fdSgReasonName: null,
                    fdSgReasonId: null,
                    fdExplain: null,
                    picked: null
                };
                $scope.ctrl.editIndex = null;
                $scope.ctrl.modal.show();
            };
            // 添加确认、编辑确认补卡申请
            $scope.confirmAdd = function(retroactive) {
                if (retroactive.picked !== null) {
                    retroactive.fdSgReasonId = $scope.views.reasons[retroactive.picked].code;
                    retroactive.fdSgReasonName = $scope.views.reasons[retroactive.picked].text;
                }
                if (!retroactive.fdLateSignatureTime) {
                    $daggerToast.show('请选择补签时间！');
                } else if (!retroactive.fdSgReasonId) {
                    $daggerToast.show('请选择补签原因！');
                } else if (!retroactive.fdExplain) {
                    $daggerToast.show('请填写补签说明！');
                } else {
                    if ($scope.ctrl.editIndex !== null) {
                        $scope.views.retroactiveList[$scope.ctrl.editIndex] = retroactive;
                        $scope.ctrl.modal.hide();
                    } else {
                        $scope.views.retroactiveList.push(retroactive);
                        $scope.ctrl.modal.hide();
                    }
                }
            };

            function calculateDateTime(newDate) {
                $scope.views.retroactive.fdLateSignatureTime = cService.dateFormat(newDate, 'yyyy-MM-dd hh:mm');
            }
            // 选中补卡时间
            $scope.selectTime = function() {
                if (CONFIGURATION.com.midea.isPcTest) {
                    var newDate = new Date();
                    calculateDateTime(newDate)
                } else {
                    widgetFactory.showPicker({
                        date: new Date(),
                        mode: 'date',
                        type: 'datetime'
                    }).then(function(newDate) {
                        calculateDateTime(newDate)
                    });
                }

            };

            /**
             * 获取加班类型
             */
            function getRetroactiveType() {
                cService.getStaticJson('retroactiveType').then(function(res) {
                    $scope.views.reasons = res;
                });
            }

            function init() {
                getRetroactiveType();
                $ionicModal.fromTemplateUrl('templates/modal.html', {
                    scope: $scope
                }).then(function(modal) {
                    $scope.ctrl.modal = modal;
                });
            }

            init();
            $scope.$apply();
        }
    ];
});