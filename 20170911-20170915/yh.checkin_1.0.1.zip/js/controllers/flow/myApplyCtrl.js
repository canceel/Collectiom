/**
 * Created  by Administrator on 14-12-29.
 */
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        'picture',
        '$timeout',
        'widgetFactory',
        '$ionicTabsDelegate',
        '$daggerToast',
        function($scope, cService, log, $rootScope, $stateParams, picture, $timeout, widgetFactory, $ionicTabsDelegate, $daggerToast) {
            $scope.views = {};

            $scope.ctrl = {
                // 请假列表
                vacationList: {
                    pageNo: 1,
                    rowSize: 10,
                    count: 0,
                    data: [],
                    hasMore: true
                },
                // 销假列表
                resumeLeaveList: {
                    pageNo: 1,
                    rowSize: 10,
                    count: 0,
                    data: [],
                    hasMore: true
                },
                // 补卡列表
                restroactiveList: {
                    pageNo: 1,
                    rowSize: 10,
                    count: 0,
                    data: [],
                    hasMore: true
                },
                // 加班列表
                overTimeList: {
                    pageNo: 1,
                    rowSize: 10,
                    count: 0,
                    data: [],
                    hasMore: true
                },
                // 调班列表
                moveShiftsList: {
                    pageNo: 1,
                    rowSize: 10,
                    count: 0,
                    data: [],
                    hasMore: true
                }
            };
            // tab切换
            $scope.onTabSelected = function(type) {
                if (type === 'vacation') {
                    if (!$scope.ctrl.vacationList.data.length) {
                        getVacationList();
                    }
                } else if (type === 'resumeLeave') {
                    if (!$scope.ctrl.resumeLeaveList.data.length) {
                        getResumeLeaveList();
                    }
                } else if (type === 'overTime') {
                    if (!$scope.ctrl.overTimeList.data.length) {
                        getOverTimeList();
                    }
                } else if (type === 'restroactive') {
                    if (!$scope.ctrl.restroactiveList.data.length) {
                        getRestroactiveList();
                    }
                } else if (type === 'moveShifts') {
                    if (!$scope.ctrl.moveShiftsList.data.length) {
                        getMoveShiftsList();
                    }
                }
            };
            // 下拉刷新
            $scope.refreshData = function(tabName) {
                console.log('ad');
                if (tabName === 'vacation') {
                    $scope.ctrl.vacationList.pageNo = 1;
                    $scope.ctrl.vacationList.data = [];
                    getVacationList();
                } else if (tabName === 'resumeLeave') {
                    $scope.ctrl.resumeLeaveList.pageNo = 1;
                    $scope.ctrl.resumeLeaveList.data = [];
                    getResumeLeaveList();
                } else if (tabName === 'overTime') {
                    $scope.ctrl.overTimeList.pageNo = 1;
                    $scope.ctrl.overTimeList.data = [];
                    getOverTimeList();
                } else if (tabName === 'restroactive') {
                    $scope.ctrl.restroactiveList.pageNo = 1;
                    $scope.ctrl.restroactiveList.data = [];
                    getRestroactiveList();
                } else if (tabName === 'moveShifts') {
                    $scope.ctrl.moveShiftsList.pageNo = 1;
                    $scope.ctrl.moveShiftsList.data = [];
                    getMoveShiftsList();
                }
            };
            // 加载更多
            $scope.loadMore = function(tabName) {
                if (tabName === 'vacation') {
                    $scope.ctrl.vacationList.pageNo++;
                    getVacationList();
                } else if (tabName === 'resumeLeave') {
                    $scope.ctrl.resumeLeaveList.pageNo++;
                    getResumeLeaveList();
                } else if (tabName === 'overTime') {
                    $scope.ctrl.overTimeList.pageNo++;
                    getOverTimeList();
                } else if (tabName === 'restroactive') {
                    $scope.ctrl.restroactiveList.pageNo++;
                    getRestroactiveList();
                } else if (tabName === 'moveShifts') {
                    $scope.ctrl.moveShiftsList.pageNo++;
                    getMoveShiftsList();
                }
            }
            // 到详情页
            $scope.toDetail = function(params) {
                params.fdKey = params.fdKey.toLowerCase();
                var p = ['mobile.production.todo', JSON.stringify({
                    fdKey: params.fdKey,
                    modelId: params.modelName,
                    fdFlowId: params.modelId,
                    extend: '{}',
                    action: 'detail'
                })];
                widgetFactory.showWidget(p).then(function(res) {

                });
            }
            /**
             * 请假
             */
            function getVacationList() {
                cService.findList('com.landray.kmss.yh.hr.model.YhHrLeave', $scope.ctrl.vacationList.pageNo, $scope.ctrl.vacationList.rowSize, {}).then(function(data) {
                    if (data.status === 1) {
                        if (data.data.length !== $scope.ctrl.vacationList.rowSize) {
                            $scope.ctrl.vacationList.hasMore = false;
                        } else {
                            $scope.ctrl.vacationList.hasMore = true;
                        }
                        $scope.ctrl.vacationList.data = $scope.ctrl.vacationList.data.concat(data.data);
                        $scope.$broadcast('scroll.refreshComplete');
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    } else {
                        $daggerToast.show('获取我的请假申请失败，请稍后重试！');
                    }
                })
            }
            /**
             * 销假
             */
            function getResumeLeaveList() {
                cService.findList('com.landray.kmss.yh.hr.model.YhHrDestroy', $scope.ctrl.resumeLeaveList.pageNo, $scope.ctrl.resumeLeaveList.rowSize, {}).then(function(data) {
                    if (data.status === 1) {
                        if (data.data.length !== $scope.ctrl.resumeLeaveList.rowSize) {
                            $scope.ctrl.resumeLeaveList.hasMore = false;
                        } else {
                            $scope.ctrl.resumeLeaveList.hasMore = true;
                        }
                        $scope.ctrl.resumeLeaveList.data = $scope.ctrl.resumeLeaveList.data.concat(data.data);
                        $scope.$broadcast('scroll.refreshComplete');
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    } else {
                        $daggerToast.show('获取我的销假申请失败，请稍后重试！');
                    }
                })
            }
            /**
             * 补卡
             */
            function getRestroactiveList() {
                cService.findList('com.landray.kmss.yh.hr.model.YhHrLateSignature', $scope.ctrl.restroactiveList.pageNo, $scope.ctrl.restroactiveList.rowSize, {}).then(function(data) {
                    if (data.status === 1) {
                        if (data.data.length !== $scope.ctrl.restroactiveList.rowSize) {
                            $scope.ctrl.restroactiveList.hasMore = false;
                        } else {
                            $scope.ctrl.restroactiveList.hasMore = true;
                        }
                        $scope.ctrl.restroactiveList.data = $scope.ctrl.restroactiveList.data.concat(data.data);
                        $scope.$broadcast('scroll.refreshComplete');
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    } else {
                        $daggerToast.show('获取我的补卡申请失败，请稍后重试！');
                    }
                })
            }
            /**
             * 加班
             */
            function getOverTimeList() {
                cService.findList('com.landray.kmss.yh.hr.model.YhHrOverwork', $scope.ctrl.overTimeList.pageNo, $scope.ctrl.overTimeList.rowSize, {}).then(function(data) {
                    if (data.status === 0) {
                        if (data.data.length !== $scope.ctrl.overTimeList.rowSize) {
                            $scope.ctrl.overTimeList.hasMore = false;
                        } else {
                            $scope.ctrl.overTimeList.hasMore = true;
                        }
                        $scope.ctrl.overTimeList.data = $scope.ctrl.overTimeList.data.concat(data.data);
                        $scope.$broadcast('scroll.refreshComplete');
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    } else {
                        $daggerToast.show('获取我的加班申请失败，请稍后重试！');
                    }
                })
            }
            /**
             * 调班
             */
            function getMoveShiftsList() {
                cService.findList('com.landray.kmss.yh.hr.model.YhHrMovework', $scope.ctrl.moveShiftsList.pageNo, $scope.ctrl.moveShiftsList.rowSize, {}).then(function(data) {
                    if (data.status === 0) {
                        if (data.data.length !== $scope.ctrl.moveShiftsList.rowSize) {
                            $scope.ctrl.moveShiftsList.hasMore = false;
                        } else {
                            $scope.ctrl.moveShiftsList.hasMore = true;
                        }
                        $scope.ctrl.moveShiftsList.data = $scope.ctrl.moveShiftsList.data.concat(data.data);
                        $scope.$broadcast('scroll.refreshComplete');
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    } else {
                        $daggerToast.show('获取我的调班申请失败，请稍后重试！');
                    }
                })
            }

            function init() {
                var applyType = $stateParams.applyType;
                if (applyType === 'resumeLeave') {
                    $ionicTabsDelegate.select(1);
                } else if (applyType === 'overtime') {
                    $ionicTabsDelegate.select(2);
                } else if (applyType === 'retroactive') {
                    $ionicTabsDelegate.select(3);
                } else {
                    // $ionicTabsDelegate.select(0);
                    getVacationList();
                }
            }
            init();
            $scope.$apply();
        }
    ];
});