/**
 * Created  by Administrator on 14-12-29.
 */
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        'picture',
        '$timeout',
        '$ionicModal',
        'widgetFactory',
        '$daggerToast',
        '$state',
        function($scope, cService, log, $rootScope, $stateParams, picture, $timeout, $ionicModal, widgetFactory, $daggerToast, $state) {
            $scope.views = {
                applyItem: null,
                fdDestroyReason: '',
                fdRealWorkDate: ''
            };

            $scope.ctrl = {
                pageNo: 1,
                rowSize: 10,
                hasMore: true,
                modal: null,
                applyList: [],
                data: {
                    fdRealWorkDate: '',
                    fdRealWorkTime: '',
                    fdDestroyReason: '',
                    fdLeaveBeginTime: '', // 开始时间
                    fdLeaveEndTime: '', // 结束时间
                    fdLeaveHourNum: '', // 请假时数
                    fdLeaveType: '', //中文
                    fdApplicationBillNum: '', // 请假单号
                    fdLeaveReason: '' // 请假事由
                }
            };

            function getApplyList() {
                cService.findList('com.landray.kmss.yh.hr.model.YhHrLeave', $scope.ctrl.pageNo, $scope.ctrl.rowSize, {}).then(function(data) {
                    if (data.status === 1) {
                        if (data.data.length !== $scope.ctrl.rowSize) {
                            $scope.ctrl.hasMore = false;
                        } else {
                            $scope.ctrl.hasMore = true;
                        }
                        $scope.ctrl.applyList = $scope.ctrl.applyList.concat(data.data);
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    } else {
                        $daggerToast.show('获取请假申请单失败，请稍后重试！');
                    }
                })
            }
            $scope.loadMore = function() {
                $scope.ctrl.pageNo++;
                getApplyList();
            };

            function calculateDateTime(prop, newDate) {
                var mon = (newDate.getMonth() + 1) <= 9 ? '0' + (newDate.getMonth() + 1) : (newDate.getMonth() + 1),
                    day = newDate.getDate() <= 9 ? '0' + newDate.getDate() : newDate.getDate(),
                    year = newDate.getFullYear(),
                    hours = newDate.getHours() <= 9 ? '0' + newDate.getHours() : newDate.getHours(),
                    minute = newDate.getMinutes() <= 9 ? '0' + newDate.getMinutes() : newDate.getMinutes();

                if (prop === 'fdRealWorkDate') {
                    $scope.ctrl.data[prop] = year + '-' + mon + '-' + day;
                    $scope.views[prop] = year + '-' + mon + '-' + day;
                } else {
                    $scope.ctrl.data[prop] = hours + ':' + minute;
                    $scope.views[prop] = hours + ':' + minute;
                }

            }


            function init() {
                $ionicModal.fromTemplateUrl('templates/myApply.html', {
                    scope: $scope
                }).then(function(modal) {
                    $scope.ctrl.modal = modal;
                    //$scope.ctrl.modal.show();
                });

                // 获取请假单列表
                getApplyList();
            }

            // 选中开始，结束时间
            $scope.selectTime = function(prop) {
                if (CONFIGURATION.com.midea.isPcTest) {
                    var newDate = new Date();

                    calculateDateTime(prop, newDate)
                } else {
                    widgetFactory.showPicker({
                        date: new Date(),
                        mode: (prop === 'fdRealWorkDate') ? 'date' : 'time',
                        type: 'day'
                    }).then(function(newDate) {
                        calculateDateTime(prop, newDate)
                    });
                }

            };

            $scope.selectApply = function(item) {
                cService.getVacationDetail(item.modelId).then(function(res) {
                    if (res.status === 0) {
                        $scope.views.applyItem = res.data;
                        $scope.ctrl.modal.hide();
                    }
                });
            };

            /*
             * 提交表单
             * */
            $scope.submitFrom = function(item) {
                if (!$scope.views.applyItem) {
                    $daggerToast.show('请先关联请假单');
                } else if (!$scope.views.fdRealWorkDate) {
                    $daggerToast.show('请先选择实际上班日期');
                } else if (!$scope.views.fdRealWorkTime) {
                    $daggerToast.show('请先选择实际上班时间');
                } else if (!$scope.ctrl.data.fdDestroyReason) {
                    $daggerToast.show('请先填写销假事由');
                } else {
                    cService.confirm('确认发起销假申请流程？').then(function(isTrue) {
                        if (isTrue) {
                            $scope.ctrl.data.fdLeaveBeginTime = $scope.views.applyItem.fdBeginTime;
                            $scope.ctrl.data.fdLeaveEndTime = $scope.views.applyItem.fdEndTime;
                            $scope.ctrl.data.fdLeaveHourNum = $scope.views.applyItem.fdLeaveHourNum;
                            $scope.ctrl.data.fdLeaveType = $scope.views.applyItem.fdLeaveType;
                            $scope.ctrl.data.fdApplicationBillNum = $scope.views.applyItem.fdApplicationBillNum;
                            $scope.ctrl.data.fdLeaveReason = $scope.views.applyItem.fdLeaveReason;
                            cService.submitResumeleave($scope.ctrl.data).then(function(res) {
                                if (1 == res.errorcode) {
                                    $daggerToast.show('销假申请提交成功');
                                    /*$state.go('myapply', {
                                        applyType: 'resumeLeave'
                                    });*/
                                    $rootScope.goBack();
                                } else {
                                    $daggerToast.show(res.errormsg);
                                }
                            });
                        }
                    })
                }
            };
            init();
            $scope.$apply();
        }
    ];
});