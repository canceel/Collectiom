/**
 * Created  by Administrator on 14-12-29.
 */
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        'picture',
        '$timeout',
        '$daggerToast',
        'widgetFactory',
        '$state',
        function($scope, cService, log, $rootScope, $stateParams, picture, $timeout, $daggerToast, widgetFactory, $state) {
            $scope.views = {
                picked: null,
                pickerSettings: {
                    lang: 'zh',
                    theme: 'ios',
                    display: 'bottom',
                    height: lib.flexible.dpr * 34, // 修正在flexible下的高度
                    showInput: false
                },
                data: [], // 请假类型

                fdBeginTime: '',
                fdEndTime: '',
                RestHours: 0,
                YearsHours: 0,
                lastyearhours: 0,
                fdAttach:[]
            };

            $scope.ctrl = {
                data: {
                    fdLeaveTypeId: null,
                    fdLeaveTypeName: '',
                    fdEndTime: '',
                    fdBeginTime: '',
                    fdLeaveHourNum: '',
                    fdLeaveReason: '',
                    fdAttach: [] // 附件：base64
                }
            };
            /**
             * 请假时长计算
             * @param  {String} prop    字段名
             * @param  {Object} newDate 日期
             */
            function calculateLeaveTime(prop, newDate) {
                if (prop && newDate) {
                    $scope.ctrl.data[prop] = newDate;
                    $scope.views[prop] = cService.dateFormat(newDate, 'yyyy/MM/dd hh:mm');
                }

                if ($scope.ctrl.data.fdBeginTime && $scope.ctrl.data.fdEndTime) {
                    if (new Date($scope.ctrl.data.fdEndTime).getTime() - new Date($scope.ctrl.data.fdBeginTime).getTime() < 0) {
                        $daggerToast.show('结束时间要大于开始时间');
                        $scope.ctrl.data.fdEndTime = '';
                        $scope.views.fdEndTime = '';
                    } else {
                        cService.calculateHours(cService.dateFormat($scope.ctrl.data.fdBeginTime, 'yyyy/MM/dd hh:mm'), cService.dateFormat($scope.ctrl.data.fdEndTime, 'yyyy/MM/dd hh:mm')).then(function(res) {
                            if (!res || !res.msg ||! res.msg.dataList || res.code === 40002) {
                                $daggerToast.show(res.msg);
                                return false;
                            }
                            if (res.msg.dataList.data && isNaN(res.msg.dataList.data.key0)) {
                                $daggerToast.show(res.msg.dataList.data.key0);
                            } else {
                                if ($scope.views.data[$scope.views.picked].code === 10 && parseFloat($scope.views.RestHours) < parseFloat(res.msg.dataList.data.key0)) {
                                    $daggerToast.show('调休时数不够用');
                                    $scope.ctrl.data.fdLeaveHourNum = '';
                                    $scope.ctrl.data.fdEndTime = '';
                                    $scope.views.fdEndTime = '';
                                } else if ($scope.views.data[$scope.views.picked].code === 3 && (parseFloat($scope.views.YearsHours) + parseFloat($scope.views.lastyearhours)) < parseFloat(res.msg.dataList.data.key0)) {
                                    $daggerToast.show('年休假时数不够用');
                                    $scope.ctrl.data.fdLeaveHourNum = '';
                                    $scope.ctrl.data.fdEndTime = '';
                                    $scope.views.fdEndTime = '';
                                } else {
                                    $scope.ctrl.data.fdLeaveHourNum = res.msg.dataList.data.key0;
                                }
                            }
                        });
                         $scope.ctrl.data.fdLeaveHourNum = '';
                    }
                }
            }
            // 拍照
            $scope.showSelect = function(index) {
                if ($scope.ctrl.data.fdAttach.length < 4) {
                    var feedback = function() {
                        var img = picture.getPictures(true);

                        picture.getBase64Codes(false, function(imgList) {
                            var params = {
                                imgId: img.imgId,
                                // fileBt64: imgList[0].replace(/\+/g, '%2B')
                                fileBt64: imgList[0]
                            };

                            $scope.views.fdAttach.push({
                                //imgBase64Str: params.fileBt64,
                                originalFileName: params.imgId + '.jpg',
                                fileSize: (params.fileBt64.length / 1024).toFixed(2),
                                src: img.getSrc()
                            });
                            $scope.ctrl.data.fdAttach.push({
                                imgBase64Str: params.fileBt64,
                                originalFileName: params.imgId + '.jpg'
                            });
                        });
                    };

                    picture.selectPicture({
                        isSingle: true,
                        allowEdit: false,
                        feedback: feedback
                    });
                }
            };
            // 删除已选图片
            $scope.reduceFile = function(index) {
                $scope.ctrl.data.fdAttach.splice(index, 1);
                $scope.views.fdAttach.splice(index, 1);
            };
            // 选中请假类型
            $scope.selectType = function() {
                $scope.ctrl.myInstance.show();
            };
            // 选中开始，结束时间
            $scope.selectTime = function(prop) {
                if (CONFIGURATION.com.midea.isPcTest) {
                    var newDate = new Date();

                    calculateLeaveTime(prop, newDate)
                } else {
                    widgetFactory.showPicker({
                        date: new Date(),
                        mode: 'date',
                        type: 'datetime'
                    }).then(function(newDate) {
                        calculateLeaveTime(prop, newDate)
                    });
                }

            };

            // 提交申请
            $scope.submitFrom = function() {
                if ($scope.views.picked !== null) {
                    $scope.ctrl.data.fdLeaveTypeId = $scope.views.data[$scope.views.picked].code;
                    $scope.ctrl.data.fdLeaveTypeName = $scope.views.data[$scope.views.picked].text;
                }
                // 字段校验
                if ($scope.views.picked === null) {
                    $daggerToast.show('请选择请假类型');
                } else if (!$scope.ctrl.data.fdBeginTime) {
                    $daggerToast.show('请选择请假开始时间');
                } else if (!$scope.ctrl.data.fdEndTime) {
                    $daggerToast.show('请选择请假结束时间');
                } else if (!$scope.ctrl.data.fdLeaveReason) {
                    $daggerToast.show('请输入请假事由');
                } else if ($scope.ctrl.data.fdLeaveTypeId && ($scope.ctrl.data.fdLeaveTypeId != 1) && ($scope.ctrl.data.fdLeaveTypeId != 14) && ($scope.ctrl.data.fdLeaveTypeId != 10) && ($scope.ctrl.data.fdLeaveTypeId != 3) && ($scope.ctrl.data.fdAttach.length === 0)) {
                    $daggerToast.show('请上传图片');
                } else if ($scope.views.data[$scope.views.picked].code === 10 && parseFloat($scope.views.RestHours) < parseFloat($scope.ctrl.data.fdLeaveHourNum)) {
                    $daggerToast.show('调休时数不够用');
                } else if ($scope.views.data[$scope.views.picked].code === 3 && (parseFloat($scope.views.YearsHours) + parseFloat($scope.views.lastyearhours)) < parseFloat($scope.ctrl.data.fdLeaveHourNum)) {
                    $daggerToast.show('年休假时数不够用');
                } else if (!$scope.ctrl.data.fdLeaveHourNum || $scope.ctrl.data.fdLeaveHourNum == 0) {
                    $daggerToast.show('请假时长必须大于0.5个小时');
                }else {
                    cService.confirm('确认发起假期申请流程？').then(function(isTrue) {
                        if (isTrue) {
                            var params = $scope.ctrl.data;
                            params.fdBeginTime = cService.dateFormat(new Date(params.fdBeginTime), 'yyyy-MM-dd hh:mm');
                            params.fdEndTime = cService.dateFormat(new Date(params.fdEndTime), 'yyyy-MM-dd hh:mm');
                            params.beginDate = $scope.views.BEGINDATE;
                            params.endDate = $scope.views.ENDDATE;
                            params.lastYearHours = $scope.views.lastyearhours;
                            params.fdExchVoctionHourCount = $scope.views.RestHours;
                            params.fdSurplusAnnVocHourNum = $scope.views.YearsHours;
                            cService.submitVacationApply(params).then(function(res) {
                                if (1 == res.errorcode) {
                                    $daggerToast.show('假期申请提交成功');
                                    $state.go('myapply', {
                                        applyType: 'vacation'
                                    });
                                    $rootScope.goBack();
                                } else {
                                    $daggerToast.show(res.errormsg);
                                }
                            });
                        }
                    })
                }
            };
            /**
             * 获取请假类型
             */
            function getVacationType() {
                cService.getStaticJson('vacationType').then(function(res) {
                    $scope.views.data = res;
                });
            }

            function init() {
                getVacationType();
                cService.getUser().then(function(user) {
                    cService.getVacationData(cService.dateFormat(new Date(), 'yyyy-MM-dd'), user.uid).then(function(res) {
                        if (res && res.length > 0) {
                            res = cService.xmlToJson2(res, 'Table');
                            // 剩余年假信息
                            if (res[0].IsLegal === '0') {
                                $scope.views.BEGINDATE = cService.dateFormat(new Date(res[0].BEGINDATE), 'yyyy-MM-dd');
                                $scope.views.ENDDATE = cService.dateFormat(new Date(res[0].ENDDATE), 'yyyy-MM-dd');
                                $scope.views.RestHours = res[0].RestHours;
                                $scope.views.YearsHours = res[0].YearsHours;
                                $scope.views.lastyearhours = res[0].lastyearhours;
                            } else {
                                $daggerToast.show(res[0].ErrorMsg);
                            }
                        }
                    })
                });

            }
            init();
            $scope.$apply();
        }
    ];
});