/**
 * Created  by Administrator on 14-12-29.
 */
define(['ionic'], function() {
    'use strict';

    return [
        '$scope',
        'cService',
        'log',
        '$rootScope',
        '$stateParams',
        'picture',
        '$timeout',
        '$ionicModal',
        '$daggerToast',
        'widgetFactory',
        '$state',
        function($scope, cService, log, $rootScope, $stateParams, picture, $timeout, $ionicModal, $daggerToast, widgetFactory, $state) {
            $scope.views = {
                overtimeList: [],
                overtime: {
                    fdOverworkDate: '', // 加班日期
                    fdBeginTime: '', // 开始时间
                    fdEndTime: '', // 结束时间
                    fdRestTime: '', // 休息时数
                    fdOverworkHourNum: '', // 加班时数
                    fdOverworkTypeId: '', // 加班类型id
                    fdOverworkTypeName: '', // 加班类型名称
                    fdOverworkReason: '', // 加班原因
                    picked: null,
                },
                pickerSettings: {
                    lang: 'zh',
                    theme: 'ios',
                    display: 'bottom',
                    height: lib.flexible.dpr * 34, // 修正在flexible下的高度
                    showInput: false
                },
                data: []
            };
            $scope.ctrl = {
                model: null,
                myInstance: null,
                overTime: {
                    fdBeginTime: null,
                    fdEndTime: null,
                    editIndex: null
                }
            };
            /**
             * 加班时间计算
             * @param  {String} prop    字段名
             * @param  {Object} newDate 日期对象
             */
            function calculateDateTime(prop, newDate) {
                if (prop === 'fdOverworkDate') {
                    $scope.views.overtime[prop] = cService.dateFormat(newDate, 'yyyy-MM-dd');
                } else if (prop === 'fdBeginTime') {
                    $scope.ctrl.overTime[prop] = newDate;
                    $scope.views.overtime[prop] = cService.dateFormat(newDate, 'hh:mm');
                } else if (prop === 'fdEndTime') {
                    //$scope.ctrl.overTime[prop] = new Date(2017, 8, 14, 19, 0, 0);
                    $scope.ctrl.overTime[prop] = newDate;
                    $scope.views.overtime[prop] = cService.dateFormat(newDate, 'hh:mm');
                }
                $scope.calculateRestTime();
            }
            $scope.calculateRestTime = function() {
                if ($scope.views.overtime.fdRestTime === '' || $scope.views.overtime.fdRestTime === null) {
                    $scope.views.overtime.fdOverworkHourNum = '';
                } else if ($scope.ctrl.overTime.fdBeginTime && $scope.ctrl.overTime.fdEndTime) {
                    var hours = ($scope.ctrl.overTime.fdEndTime.getTime() - $scope.ctrl.overTime.fdBeginTime.getTime()) / 3600000 - parseFloat($scope.views.overtime.fdRestTime);
                    hours = hours.toFixed(1);
                    if (hours < parseInt(hours) + 0.5) {
                        hours = parseInt(hours);
                    } else {
                        hours = parseInt(hours) + 0.5;
                    }
                    if (!(hours > 0)) {
                        $daggerToast.show('最小加班时长应大于0');
                        $timeout(function() {
                            $scope.views.overtime.fdRestTime = '';
                        }, 2000);
                    } else {
                        $scope.views.overtime.fdOverworkHourNum = hours;
                    }
                }
            }
            // 提交申请
            $scope.submitFrom = function() {
                if ($scope.views.overtimeList.length === 0) {
                    $daggerToast.show('请先添加加班申请');
                } else {
                    cService.confirm('确认发起加班申请流程？').then(function(isTrue) {
                        if (isTrue) {
                            cService.submitOverworkApply({ fdOverworkList: $scope.views.overtimeList }).then(function(res) {
                                if (1 == res.errorcode) {
                                    $daggerToast.show('加班申请提交成功');
                                    /*$state.go('myapply', {
                                        applyType: 'overtime'
                                    });*/
                                    $rootScope.goBack();
                                } else {
                                    $daggerToast.show(res.errormsg);
                                }
                            });
                        }
                    })
                }
            };

            // 添加确认、编辑确认加班申请
            $scope.confirmAdd = function(overtime) {
                if (overtime.picked !== null) {
                    overtime.fdOverworkTypeId = $scope.views.data[overtime.picked].code;
                    overtime.fdOverworkTypeName = $scope.views.data[overtime.picked].text;
                }
                if (!overtime.fdOverworkDate) {
                    $daggerToast.show('请选择加班日期！');
                } else if (!overtime.fdBeginTime) {
                    $daggerToast.show('请选择开始时间！');
                } else if (!overtime.fdEndTime) {
                    $daggerToast.show('请选择结束时间！');
                } else if (!overtime.fdRestTime && overtime.fdRestTime !== 0) {
                    $daggerToast.show('请输入休息时数！');
                } else if (overtime.fdRestTime && overtime.fdRestTime < 0) {
                    $daggerToast.show('休息时数填写有误！');
                } else if (!overtime.fdOverworkTypeId && overtime.fdOverworkTypeId !== 0) {
                    $daggerToast.show('请选择加班类型！');
                } else if (!overtime.fdOverworkReason || (overtime.fdOverworkReason && overtime.fdOverworkReason === '')) {
                    $daggerToast.show('请填写加班原因！');
                } else {
                    if ($scope.ctrl.overTime.editIndex !== null) {
                        $scope.views.overtimeList[$scope.ctrl.overTime.editIndex] = overtime;
                        $scope.ctrl.modal.hide();
                    } else {
                        $scope.views.overtimeList.push(overtime);
                        $scope.ctrl.modal.hide();
                    }
                }
            };
            // 添加加班申请
            $scope.addApply = function() {
                $scope.views.overtime = {
                    fdOverworkDate: '',
                    fdBeginTime: '',
                    fdEndTime: '',
                    fdRestTime: '',
                    fdOverworkHourNum: '',
                    fdOverworkTypeId: '',
                    fdOverworkTypeName: '', // 加班类型名称
                    fdOverworkReason: '',
                    picked: null
                };
                $scope.ctrl.overTime.editIndex = null;
                $scope.ctrl.modal.show();
            };
            // 删除加班申请
            $scope.deleteApply = function(index) {
                // 删除
                $scope.views.overtimeList.splice(index, 1);
            }
            // 编辑加班申请
            $scope.editApply = function(index, item) {
                $scope.ctrl.overTime.editIndex = index;
                $scope.views.overtime = item;
                $scope.ctrl.modal.show();
            };
            // 选中请假类型
            $scope.selectType = function() {
                $scope.ctrl.myInstance.show();
            };
            // 选中开始，结束时间
            $scope.selectTime = function(prop) {
                if (CONFIGURATION.com.midea.isPcTest) {
                    var newDate = new Date();

                    calculateDateTime(prop, newDate)
                } else {
                    widgetFactory.showPicker({
                        date: new Date(),
                        mode: (prop === 'fdOverworkDate') ? 'date' : 'time',
                        type: 'day'
                    }).then(function(newDate) {
                        calculateDateTime(prop, newDate)
                    });
                }

            };
            /**
             * 获取加班类型
             */
            function getOverworkType() {
                cService.getStaticJson('overWorkType').then(function(res) {
                    $scope.views.data = res;
                });
            }

            function init() {
                getOverworkType();
                $ionicModal.fromTemplateUrl('templates/modal.html', {
                    scope: $scope
                }).then(function(modal) {
                    $scope.ctrl.modal = modal;
                });
            }
            init();
            $scope.$apply();
        }
    ];
});