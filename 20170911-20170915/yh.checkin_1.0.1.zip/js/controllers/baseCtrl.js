/**
 * Created by Administrator on 14-12-29.
 */
define([], function() {
    'use strict';

    return [
        'widgetFactory',
        '$ionicPlatform',
        '$ionicHistory',
        '$rootScope',
        '$ionicLoading',
        '$sce',
        function(widgetFactory, $ionicPlatform, $ionicHistory, $rootScope, $ionicLoading, $sce) {
            // 隐藏浮动按钮
            widgetFactory.hideFloat();
            // 隐藏导航控件
            widgetFactory.hideNav();
            // 苹果状态栏变色
            widgetFactory.changeColor([
                253,
                253,
                253,
                1
            ]);
            $rootScope.indexStateList = ['home']; // 重写默认首页，当首页有多个页面时候，可以添加，多用于tab中多个页面
            $rootScope.ModalStateList = []; // 保存Modal弹出层对象，用于硬件返回关闭弹出层
            $rootScope.isHome = false;

            $rootScope.showImgSrc = '';
            $rootScope.showImgSrcTag = false;


            $rootScope.showUploadImg = function(e, attachment) {
                e.stopPropagation();
                $rootScope.showImgSrc = $sce.trustAsResourceUrl(attachment);
                $rootScope.showImgSrcTag = true;
            };
            $rootScope.hideCommentImg = function() {
                $rootScope.showImgSrcTag = false;
            };
            // 返回上一页
            $rootScope.goBack = function() {
                if ($rootScope.isHome) {
                    // 返回底座
                    widgetFactory.exit();
                } else {
                    // 返回上一页
                    if ($ionicHistory.backView()) {
                        $ionicHistory.goBack();
                    } else {
                        widgetFactory.exit();
                    }
                }
            };

            $ionicPlatform.registerBackButtonAction(function() {
                if (window.CONFIGURATION.isShowLoading) {
                    $ionicLoading.hide();
                    window.CONFIGURATION.isShowLoading = false;

                    return;
                }

                if ($rootScope.ModalStateList.length > 0) {
                    var modal = $rootScope.ModalStateList.pop();

                    modal.hide();
                } else {
                    $rootScope.goBack();
                }
            }, 100, 'main');
        }
    ];
});
